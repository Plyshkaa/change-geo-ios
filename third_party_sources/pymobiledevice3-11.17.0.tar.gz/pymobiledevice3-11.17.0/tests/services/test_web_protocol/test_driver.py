from pymobiledevice3.services.web_protocol.driver import By
from tests.services.test_web_protocol.common import LINK_HTML, PAGE_ONE, PAGE_TWO


async def test_back(webdriver):
    await webdriver.get(PAGE_ONE)
    await webdriver.get(PAGE_TWO)
    await webdriver.back()
    assert await webdriver.get_current_url() == PAGE_ONE


async def test_current_url(webdriver):
    assert not await webdriver.get_current_url()
    await webdriver.get(PAGE_ONE)
    assert await webdriver.get_current_url() == PAGE_ONE


async def test_forward(webdriver):
    await webdriver.get(PAGE_ONE)
    await webdriver.get(PAGE_TWO)
    await webdriver.back()
    await webdriver.forward()
    assert await webdriver.get_current_url() == PAGE_TWO


async def test_find_element(webdriver):
    await webdriver.execute_script(f"""document.getElementsByTagName('body')[0].innerHTML = '{LINK_HTML}'; """)
    by_id = await webdriver.find_element(By.ID, "id_of_link")
    by_xpath = await webdriver.find_element(By.XPATH, "/html/body/a")
    by_link_text = await webdriver.find_element(By.LINK_TEXT, "the text obviously")
    by_partial_link_text = await webdriver.find_element(By.PARTIAL_LINK_TEXT, "obviously")
    by_name = await webdriver.find_element(By.NAME, "name_of_link")
    by_tag = await webdriver.find_element(By.TAG_NAME, "a")
    by_class = await webdriver.find_element(By.CLASS_NAME, "link-class")
    by_css = await webdriver.find_element(By.CSS_SELECTOR, ".link-class")
    assert by_id == by_xpath == by_link_text == by_partial_link_text == by_name == by_tag == by_class == by_css
    assert by_id is not None
