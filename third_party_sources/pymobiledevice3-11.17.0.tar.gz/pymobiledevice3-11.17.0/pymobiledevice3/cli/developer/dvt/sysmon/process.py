import asyncio
import contextlib
import json
import re
import sys
from collections.abc import AsyncIterator
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Annotated, Any, Optional, TextIO, cast

import typer
from typer_injector import InjectingTyper

from pymobiledevice3.cli.cli_common import (
    ServiceProviderDep,
    async_command,
    default_json_encoder,
    print_json,
    prompt_selection,
)
from pymobiledevice3.services.dvt.instruments.device_info import DeviceInfo
from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
from pymobiledevice3.services.dvt.instruments.sysmontap import Sysmontap

cli = InjectingTyper(
    name="process",
    help="Process monitor options.",
    no_args_is_help=True,
)

monitor_cli = InjectingTyper(
    name="monitor",
    help="Continuously stream process metrics.",
    no_args_is_help=True,
)
cli.add_typer(monitor_cli)

_BYTE_FIELDS = {
    "anonMemoryUsage",
    "diskBytesRead",
    "diskBytesWritten",
    "memAnon",
    "memAnonPeak",
    "memCompressed",
    "memPurgeable",
    "memRPrvt",
    "memRShrd",
    "memResidentSize",
    "memVirtualSize",
    "physFootprint",
    "purgeableMemory",
    "wiredMemory",
    "wiredSize",
}

_NANOSECOND_FIELDS = {
    "cpuTotalSystem",
    "cpuTotalUser",
    "procAge",
    "threadsSystem",
    "threadsUser",
}

_PROCESS_FILTER_PATTERN = re.compile(r"(?P<key>[^=]+)=(?P<value>.*)")


class ProcessSelectionMode(str, Enum):
    PROMPT = "prompt"
    FIRST = "first"
    LAST = "last"


ProcessFilterExpressions = Annotated[
    Optional[list[str]],
    typer.Option(
        "--filter",
        "-f",
        help="Filter processes by key=value. Can be specified multiple times.",
    ),
]

ProcessKeys = Annotated[
    Optional[list[str]],
    typer.Option(
        "--key",
        "-k",
        help="Show only selected process keys for each emitted record. Can be specified multiple times.",
    ),
]

ProcessMonitorDuration = Annotated[
    Optional[int],
    typer.Option(
        "--duration",
        "-d",
        help="Maximum duration in milliseconds to run monitoring (optional)",
    ),
]

HumanReadableProcessValues = Annotated[
    bool,
    typer.Option(
        "--human",
        help=(
            "Format known byte-count fields such as physFootprint using human-readable units, "
            "and nanosecond fields such as cpuTotalUser as durations."
        ),
    ),
]

KeepMonitoringProcess = Annotated[
    bool,
    typer.Option(
        "--keep-monitoring",
        help=(
            "Re-apply the filters on every snapshot instead of locking onto the process selected from the first one. "
            "Snapshots where nothing matches are skipped instead of ending the command, and a relaunched process is "
            'picked up again automatically. Requires "--choose first" or "--choose last".'
        ),
    ),
]

ProcessResultsOutputPath = Annotated[
    Optional[Path],
    typer.Option(
        "--output",
        "-o",
        help="Output file path for JSONL format (optional, defaults to stdout)",
    ),
]


def _parse_process_filters(filter_expressions: Optional[list[str]]) -> dict[str, list[str]]:
    parsed_filters: dict[str, list[str]] = {}
    if filter_expressions:
        for raw in filter_expressions:
            match = _PROCESS_FILTER_PATTERN.fullmatch(raw)
            if match is None:
                raise typer.BadParameter(f'Invalid filter "{raw}". Expected key=value.')
            key = match.group("key")
            value = match.group("value")
            parsed_filters.setdefault(key, []).append(value)
    return parsed_filters


def _validate_process_keys(process: dict[str, Any], keys: list[str]) -> None:
    unknown_keys = [key for key in keys if key not in process]
    if unknown_keys:
        raise typer.BadParameter(
            f"The process does not have the following keys: {unknown_keys}. Possible keys={list(process.keys())}"
        )


def _matches_filters(proc: dict[str, Any], parsed_filters: dict[str, list[str]]) -> bool:
    if len(parsed_filters) == 0:
        return True
    return all(str(proc.get(key)) in values for key, values in parsed_filters.items())


def _select_process_output_keys(process: dict[str, Any], output_keys: Optional[list[str]]) -> dict[str, Any]:
    if not output_keys:
        return process

    _validate_process_keys(process, output_keys)
    return {key: process[key] for key in output_keys}


def _format_byte_count(value: int) -> str:
    suffixes = ("B", "KB", "MB", "GB", "TB", "PB")
    size = float(value)
    suffix_index = 0
    while size >= 1024 and suffix_index < len(suffixes) - 1:
        size /= 1024
        suffix_index += 1
    if suffix_index == 0:
        return f"{int(size)}{suffixes[suffix_index]}"
    return f"{size:.1f}{suffixes[suffix_index]}" if size < 10 else f"{size:.0f}{suffixes[suffix_index]}"


def _format_duration_ns(value: int) -> str:
    total_seconds, ns_remainder = divmod(value, 1_000_000_000)
    if total_seconds == 0:
        return f"{ns_remainder // 1_000_000}ms"
    parts: list[str] = []
    for suffix, unit_seconds in (("d", 86400), ("h", 3600), ("m", 60), ("s", 1)):
        unit_value, total_seconds = divmod(total_seconds, unit_seconds)
        if unit_value:
            parts.append(f"{unit_value}{suffix}")
    return " ".join(parts)


def _humanize_process_values(process: dict[str, Any]) -> dict[str, Any]:
    humanized = dict(process)
    for key, value in humanized.items():
        if not isinstance(value, int):
            continue
        if key in _BYTE_FIELDS:
            humanized[key] = _format_byte_count(value)
        elif key in _NANOSECOND_FIELDS:
            humanized[key] = _format_duration_ns(value)
    return humanized


def _add_derived_fields(process: dict[str, Any]) -> dict[str, Any]:
    with_derived = dict(process)
    cpu_total_user = process.get("cpuTotalUser")
    cpu_total_system = process.get("cpuTotalSystem")
    proc_age = process.get("procAge")
    if (
        isinstance(cpu_total_user, int)
        and isinstance(cpu_total_system, int)
        and isinstance(proc_age, int)
        and proc_age > 0
    ):
        # Lifetime average CPU on the same percent-of-core scale as cpuUsage; comparing the two
        # tells chronic hogs apart from momentary spikes.
        with_derived["cpuUsageLifetime"] = (cpu_total_user + cpu_total_system) / proc_age * 100
    return with_derived


def _serialize_process(
    process: dict[str, Any], keys: Optional[list[str]] = None, human: bool = False
) -> dict[str, Any]:
    selected = dict(_select_process_output_keys(process, keys))
    if human:
        selected = _humanize_process_values(selected)
    selected["timestamp"] = datetime.now(timezone.utc).isoformat()
    return selected


def _write_process(out: Optional[TextIO], process: dict[str, Any]) -> None:
    if out is None:
        print_json(process)
        return

    json_output = json.dumps(process, default=default_json_encoder)
    out.write(json_output + "\n")
    out.flush()


def _write_json(out: Optional[TextIO], value: Any) -> None:
    if out is None:
        print_json(value)
        return

    out.write(json.dumps(value, sort_keys=True, indent=4, default=default_json_encoder) + "\n")
    out.flush()


def _write_status(line: str) -> None:
    print(line, flush=True)


def _describe_process(process: dict[str, Any]) -> str:
    name = process.get("name") or process.get("comm") or "<unknown>"
    pid = process.get("pid")
    ppid = process.get("ppid")
    return f"pid={pid}, ppid={ppid}, name={name}"


def _describe_processes(processes: list[dict[str, Any]]) -> str:
    return "; ".join(_describe_process(process) for process in processes)


def _duration_elapsed(start_time: float, duration_ms: Optional[int]) -> bool:
    if duration_ms is None:
        return False
    return ((asyncio.get_running_loop().time() - start_time) * 1000) >= duration_ms


def _should_skip_first_snapshot(keys: Optional[list[str]]) -> bool:
    # The first sample does not contain initialized cpuUsage values
    return (keys is None) or ("cpuUsage" in keys)


async def iter_processes(sysmon: Sysmontap, skip_first_snapshot: bool = False) -> AsyncIterator[list[dict[str, Any]]]:
    should_skip_snapshot = skip_first_snapshot
    async for process_snapshot in cast(AsyncIterator[list[dict[str, Any]]], sysmon.iter_processes()):
        if should_skip_snapshot:
            should_skip_snapshot = False
            continue
        yield [_add_derived_fields(process) for process in process_snapshot]


def _process_sort_key(process: dict[str, Any]) -> tuple[int, int, str]:
    # Sort from oldest to newest process. "first" picks the oldest match and "last" picks the newest match.
    start_abs_time = process.get("startAbsTime")
    if not isinstance(start_abs_time, int):
        start_abs_time = -1
    pid = process.get("pid")
    if not isinstance(pid, int):
        pid = -1
    name = process.get("name") or process.get("comm") or ""
    return start_abs_time, pid, str(name)


def _select_process_from_candidates(
    processes: list[dict[str, Any]], selection_mode: ProcessSelectionMode
) -> dict[str, Any]:
    if len(processes) == 1:
        return processes[0]

    sorted_processes = sorted(processes, key=_process_sort_key)

    if selection_mode == ProcessSelectionMode.FIRST:
        return sorted_processes[0]
    if selection_mode == ProcessSelectionMode.LAST:
        return sorted_processes[-1]

    if not sys.stdin.isatty():
        raise typer.BadParameter(
            f'Multiple processes matched the given filters. Re-run with "--choose first", "--choose last", or refine the filters. '
            f"Matches: {_describe_processes(processes)}"
        )

    selection_index = cast(
        int,
        prompt_selection(
            [_describe_process(process) for process in sorted_processes],
            "Choose process to monitor",
            idx=True,
        ),
    )
    return sorted_processes[selection_index]


def _get_process_identifier(process: dict[str, Any]) -> tuple[str, object]:
    if process.get("uniqueID") is not None:
        return "uniqueID", process["uniqueID"]
    if process.get("startAbsTime") is not None:
        return "startAbsTime", process["startAbsTime"]
    return "pid", process["pid"]


def _matches_selected_process(process: dict[str, Any], selected_process_identifier: tuple[str, object]) -> bool:
    identifier_key, identifier_value = selected_process_identifier
    return process.get(identifier_key) == identifier_value


def _resolve_matching_process(
    process_snapshot: list[dict[str, Any]],
    parsed_filters: dict[str, list[str]],
    selection_mode: ProcessSelectionMode,
) -> Optional[dict[str, Any]]:
    """Re-apply the filters against a single snapshot. Returns None when nothing currently matches."""
    # All process entries in a sysmon sample share the same schema, so validating one entry is sufficient.
    _validate_process_keys(process_snapshot[0], list(parsed_filters))

    matching_processes = [process for process in process_snapshot if _matches_filters(process, parsed_filters)]
    if len(matching_processes) == 0:
        return None

    return _select_process_from_candidates(matching_processes, selection_mode)


def _resolve_tracked_process(
    process_snapshot: list[dict[str, Any]],
    tracked_process_identifier: tuple[str, object],
    tracked_process_description: str,
) -> Optional[dict[str, Any]]:
    """Locate the process locked in at selection time. Returns None once it is absent from the snapshot."""
    tracked_process_matches = [
        process for process in process_snapshot if _matches_selected_process(process, tracked_process_identifier)
    ]

    if len(tracked_process_matches) == 0:
        return None

    if len(tracked_process_matches) > 1:
        matching_processes_description = [_describe_process(process) for process in tracked_process_matches]
        raise typer.BadParameter(
            f"Selected process identity is ambiguous for {tracked_process_description!r}. "
            f"Matching processes: {matching_processes_description}. Please refine the filters."
        )

    return tracked_process_matches[0]


def _select_process_from_snapshot(
    process_snapshot: list[dict[str, Any]],
    parsed_filters: dict[str, list[str]],
    selection_mode: ProcessSelectionMode,
) -> dict[str, Any]:
    selected_process = (
        _resolve_matching_process(process_snapshot, parsed_filters, selection_mode) if process_snapshot else None
    )
    if selected_process is None:
        raise typer.BadParameter("Failed to find a process matching the given filters in the current snapshot")

    return selected_process


async def _select_process_from_sysmon(
    dvt: DvtProvider,
    parsed_filters: dict[str, list[str]],
    keys: Optional[list[str]],
    selection_mode: ProcessSelectionMode,
) -> dict[str, Any]:
    async with await Sysmontap.create(dvt) as selection_sysmon:
        async for process_snapshot in iter_processes(
            selection_sysmon, skip_first_snapshot=_should_skip_first_snapshot(keys)
        ):
            # All process entries in a sysmon sample share the same schema, so validating one entry is sufficient.
            _validate_process_keys(process_snapshot[0], keys or [])
            return _select_process_from_snapshot(process_snapshot, parsed_filters, selection_mode)

    raise typer.BadParameter("Failed to collect a process snapshot")


@cli.command("single")
@async_command
async def sysmon_process_single(
    service_provider: ServiceProviderDep,
    filter_expressions: ProcessFilterExpressions = None,
    keys: ProcessKeys = None,
    human: HumanReadableProcessValues = False,
    output: ProcessResultsOutputPath = None,
) -> None:
    """show a single snapshot of currently running processes."""
    with contextlib.ExitStack() as stack:
        out = stack.enter_context(open(output, "w")) if output else None
        await sysmon_process_single_task(service_provider, filter_expressions, keys, human, out)


async def sysmon_process_single_task(
    service_provider: ServiceProviderDep,
    filter_expressions: Optional[list[str]] = None,
    keys: Optional[list[str]] = None,
    human: bool = False,
    out: Optional[TextIO] = None,
) -> None:
    parsed_filters = _parse_process_filters(filter_expressions)
    result: list[dict[str, Any]] = []
    async with (
        DvtProvider(service_provider) as dvt,
        DeviceInfo(dvt) as device_info,
        await Sysmontap.create(dvt) as sysmon,
    ):
        async for process_snapshot in iter_processes(sysmon, skip_first_snapshot=_should_skip_first_snapshot(keys)):
            if process_snapshot and parsed_filters:
                # All process entries in a sysmon sample share the same schema, so validating one entry is sufficient.
                _validate_process_keys(process_snapshot[0], list(parsed_filters))

            for process in process_snapshot:
                if not _matches_filters(process, parsed_filters):
                    continue

                process = dict(process)
                process["execName"] = await device_info.execname_for_pid(process["pid"])
                result.append(_serialize_process(process, keys, human))

            break

    if len(result) == 0:
        if parsed_filters:
            raise typer.BadParameter("Failed to find a process matching the given filters in the current snapshot")
        raise typer.BadParameter("Failed to find any processes in the current snapshot")

    _write_json(out, result)


@monitor_cli.command("threshold")
@async_command
async def sysmon_process_monitor_threshold(
    service_provider: ServiceProviderDep,
    threshold: Annotated[float, typer.Argument(help="Minimum cpuUsage value to emit")],
    keys: ProcessKeys = None,
    duration: ProcessMonitorDuration = None,
    human: HumanReadableProcessValues = False,
    output: ProcessResultsOutputPath = None,
) -> None:
    """Continuously monitor processes above a cpuUsage threshold."""

    with contextlib.ExitStack() as stack:
        out = stack.enter_context(open(output, "w")) if output else None
        await sysmon_process_monitor_threshold_task(service_provider, threshold, duration, keys, human, out)


@monitor_cli.command("process")
@async_command
async def sysmon_process_monitor_process(
    service_provider: ServiceProviderDep,
    filter_expressions: ProcessFilterExpressions = None,
    keys: ProcessKeys = None,
    choose: Annotated[
        ProcessSelectionMode,
        typer.Option(
            "--choose",
            help=(
                'How to resolve multiple matching processes: "prompt" asks interactively; '
                '"first" selects the oldest matching process; "last" selects the newest matching process. '
                "Automatic ordering is by startAbsTime, then pid, then name."
            ),
        ),
    ] = ProcessSelectionMode.PROMPT,
    keep_monitoring: KeepMonitoringProcess = False,
    interval: Annotated[
        int,
        typer.Option(
            "--interval",
            "-i",
            help="Minimum interval in milliseconds between outputs (optional)",
        ),
    ] = Sysmontap.DEFAULT_INTERVAL_MS,
    duration: ProcessMonitorDuration = None,
    human: HumanReadableProcessValues = False,
    output: ProcessResultsOutputPath = None,
) -> None:
    """Continuously monitor one process selected from the current snapshot by key=value filters."""

    with contextlib.ExitStack() as stack:
        out = stack.enter_context(open(output, "w")) if output else None
        await sysmon_process_monitor_process_task(
            service_provider, filter_expressions, interval, duration, choose, keys, human, out, keep_monitoring
        )


async def sysmon_process_monitor_threshold_task(
    service_provider: ServiceProviderDep,
    threshold: float,
    duration: Optional[int] = None,
    keys: Optional[list[str]] = None,
    human: bool = False,
    out: Optional[TextIO] = None,
) -> None:
    """Continuously monitor processes above a cpuUsage threshold."""

    start_time = None

    async with DvtProvider(service_provider) as dvt, await Sysmontap.create(dvt) as sysmon:
        async for process_snapshot in iter_processes(sysmon, skip_first_snapshot=True):
            if start_time is None:
                start_time = asyncio.get_running_loop().time()

            if _duration_elapsed(start_time, duration):
                break

            if process_snapshot:
                # All process entries in a sysmon sample share the same schema, so validating one entry is sufficient.
                _validate_process_keys(process_snapshot[0], keys or [])

            for process in process_snapshot:
                if process.get("cpuUsage") is None or process["cpuUsage"] < threshold:
                    continue

                _write_process(out, _serialize_process(process, keys, human))

            if _duration_elapsed(start_time, duration):
                # Avoid waiting for the next snapshot
                break


async def sysmon_process_monitor_process_task(
    service_provider: ServiceProviderDep,
    filter_expressions: Optional[list[str]] = None,
    interval: int = Sysmontap.DEFAULT_INTERVAL_MS,
    duration: Optional[int] = None,
    choose: ProcessSelectionMode = ProcessSelectionMode.PROMPT,
    keys: Optional[list[str]] = None,
    human: bool = False,
    out: Optional[TextIO] = None,
    keep_monitoring: bool = False,
) -> None:
    """Continuously monitor one process selected from the current snapshot by key=value filters."""

    parsed_filters = _parse_process_filters(filter_expressions)

    if keep_monitoring and choose == ProcessSelectionMode.PROMPT:
        raise typer.BadParameter(
            '"--keep-monitoring" re-selects the monitored process on every snapshot, so it cannot prompt for one. '
            'Re-run with "--choose first" or "--choose last".'
        )

    async with DvtProvider(service_provider) as dvt:
        selected_process_identifier: Optional[tuple[str, object]] = None
        selected_process_description = ""

        if not keep_monitoring:
            selected_process = await _select_process_from_sysmon(dvt, parsed_filters, keys, choose)
            selected_process_identifier = _get_process_identifier(selected_process)
            selected_process_description = _describe_process(selected_process)

            _write_status(f"Monitoring {selected_process_description}")

        monitoring_start_time = None
        async with await Sysmontap.create(dvt, interval=interval) as monitor_sysmon:
            async for process_snapshot in iter_processes(
                monitor_sysmon, skip_first_snapshot=_should_skip_first_snapshot(keys)
            ):
                if monitoring_start_time is None:
                    monitoring_start_time = asyncio.get_running_loop().time()

                if _duration_elapsed(monitoring_start_time, duration):
                    break

                if len(process_snapshot) == 0:
                    continue

                # All process entries in a sysmon sample share the same schema, so validating one entry is sufficient.
                _validate_process_keys(process_snapshot[0], keys or [])

                if keep_monitoring:
                    monitored_process = _resolve_matching_process(process_snapshot, parsed_filters, choose)
                    if monitored_process is None:
                        # A snapshot may transiently omit the process, and a relaunched one reappears later on.
                        continue

                    monitored_process_identifier = _get_process_identifier(monitored_process)
                    if monitored_process_identifier != selected_process_identifier:
                        selected_process_identifier = monitored_process_identifier
                        _write_status(f"Monitoring {_describe_process(monitored_process)}")
                else:
                    assert selected_process_identifier is not None  # always resolved when not keep_monitoring
                    monitored_process = _resolve_tracked_process(
                        process_snapshot, selected_process_identifier, selected_process_description
                    )
                    if monitored_process is None:
                        _write_status(f"Selected process exited: {selected_process_description}")
                        break

                _write_process(out, _serialize_process(monitored_process, keys, human))

                if _duration_elapsed(monitoring_start_time, duration):
                    # Avoid waiting for the next snapshot
                    break
