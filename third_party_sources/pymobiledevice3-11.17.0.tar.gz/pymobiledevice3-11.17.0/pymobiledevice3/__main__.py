import asyncio
import difflib
import enum
import importlib
import logging
import os
import re
import shutil
import sys
import textwrap
import traceback
import warnings
from typing import Annotated, Any, Callable, Optional, Union, cast

import coloredlogs
import typer
from packaging.version import Version
from typer.core import TyperGroup
from typer_injector import InjectingTyper

try:
    import shellingham
except ImportError:  # pragma: no cover
    shellingham = None

# Must precede the other first-party imports (isort keeps it first) so their dependency
# chains are lazy on Python 3.15+; see the module docstring.
import pymobiledevice3._lazy_imports  # noqa: F401
from pymobiledevice3.cli.cli_common import (
    FORCE_TUNNEL_ENV_VAR,
    NATIVE_ENV_VAR,
    RECONNECT_ANY_ENV_VAR,
    TUNNEL_ENV_VAR,
    UDID_ENV_VAR,
    USERSPACE_ENV_VAR,
    _cli_udid,
    default_transport_preference,
    isatty,
    resolved_udid,
    set_color_flag,
    set_verbosity,
)
from pymobiledevice3.exceptions import (
    AccessDeniedError,
    AfcException,
    AfcFileNotFoundError,
    CloudConfigurationAlreadyPresentError,
    ConnectionFailedError,
    ConnectionFailedToUsbmuxdError,
    ConnectionTerminatedError,
    CoreDeviceError,
    CryptexdError,
    DeprecationError,
    DeveloperModeError,
    DeveloperModeIsNotEnabledError,
    DeviceFeatureNotSupportedError,
    DeviceHasPasscodeSetError,
    DeviceNotFoundError,
    DevicePathError,
    FeatureNotSupportedError,
    InstallCoordinationError,
    InternalError,
    InvalidServiceError,
    MessageNotSupportedError,
    MissingValueError,
    NoDeviceConnectedError,
    NotPairedError,
    OSNotSupportedError,
    PairingDialogResponsePendingError,
    PasswordRequiredError,
    QuicProtocolNotSupportedError,
    RoutableTunnelRequiredError,
    RSDRequiredError,
    SetProhibitedError,
    StartServiceError,
    TunneldConnectionError,
    UserDeniedPairingError,
    UserspaceTunnelUnavailableError,
)
from pymobiledevice3.lockdown import retry_create_using_usbmux
from pymobiledevice3.osu.os_utils import get_os_utils

cast(Any, coloredlogs).install(level=logging.INFO)

logging.getLogger("quic").setLevel(logging.CRITICAL + 1)
logging.getLogger("asyncio").setLevel(logging.CRITICAL + 1)
logging.getLogger("parso").setLevel(logging.CRITICAL + 1)
logging.getLogger("humanfriendly").setLevel(logging.CRITICAL + 1)
logging.getLogger("blib2to3").setLevel(logging.CRITICAL + 1)
logging.getLogger("urllib3").setLevel(logging.CRITICAL + 1)

logger = logging.getLogger(__name__)

# For issue https://github.com/doronz88/pymobiledevice3/issues/1217, details: https://bugs.python.org/issue37373
if sys.platform == "win32":
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

INVALID_SERVICE_MESSAGE = """Failed to start service. Possible reasons are:
- If you were trying to access a developer service (developer subcommand):
    - If your device iOS version >= 16.0:
        - Make sure you first enabled "Developer Mode" via:
          > python3 -m pymobiledevice3 amfi enable-developer-mode

    - Make sure the DeveloperDiskImage/PersonalizedImage is mounted via:
      > python3 -m pymobiledevice3 mounter auto-mount

    - If your device iOS version >= 17.0:
        - An RSD tunnel is established automatically; no flag is needed.
        - On Linux/Windows with iOS 17.0-17.3, a privileged tunneld must be running:
          > sudo python3 -m pymobiledevice3 remote tunneld
          https://doronz88.github.io/pymobiledevice3/guides/ios17-tunnels/

- Apple removed this service, or your iOS version does not support it.

- A bug. Please file a bug report:
  https://github.com/doronz88/pymobiledevice3/issues/new?assignees=&labels=&projects=&template=bug_report.md&title=
"""

CONTEXT_SETTINGS: dict[str, Any] = {"help_option_names": ["-h", "--help"], "max_content_width": 400}

# Mapping of index options to import file names
CLI_GROUPS = {
    "activation": "activation",
    "afc": "afc",
    "amfi": "amfi",
    "apps": "apps",
    "backup2": "backup",
    "btlogger": "btlogger",
    "bonjour": "bonjour",
    "companion": "companion_proxy",
    "crash": "crash",
    "cryptex": "cryptex",
    "developer": "developer",
    "diagnostics": "diagnostics",
    "lockdown": "lockdown",
    "mounter": "mounter",
    "notification": "notification",
    "pcap": "pcap",
    "power-assertion": "power_assertion",
    "processes": "processes",
    "profile": "profile",
    "provision": "provision",
    "remote": "remote",
    "restore": "restore",
    "springboard": "springboard",
    "syslog": "syslog",
    "usbmux": "usbmux",
    "webinspector": "webinspector",
    "idam": "idam",
    "version": "version",
}

# Set if used the `--reconnect` option
RECONNECT = False
_ORIGINAL_SHELLINGHAM_DETECT: Optional[Callable[[], tuple[str, str]]] = None


class ExitCode(enum.IntEnum):
    """Process exit codes returned by `main()`."""

    SUCCESS = 0
    ERROR = 1
    ABORTED = 130  # SIGINT convention: 128 + signal number


def _detect_shell_for_completion() -> tuple[str, str]:
    assert _ORIGINAL_SHELLINGHAM_DETECT is not None  # set by _patch_xonsh_completion_detection before use
    shell, executable = _ORIGINAL_SHELLINGHAM_DETECT()
    if shell == "xonsh":
        return ("fish" if shutil.which("fish") else "bash"), executable
    return shell, executable


def _patch_xonsh_completion_detection() -> None:
    """Let Typer install fish completions for xonsh when available, otherwise bash."""
    global _ORIGINAL_SHELLINGHAM_DETECT

    if shellingham is None:
        return

    detect_shell = cast(Any, shellingham).detect_shell
    _ORIGINAL_SHELLINGHAM_DETECT = getattr(detect_shell, "_pymobiledevice3_original", detect_shell)
    if getattr(detect_shell, "_pymobiledevice3_xonsh_patched", False):
        return

    # Stash the original detector on the replacement function so re-invocations are idempotent.
    _detect_shell_for_completion._pymobiledevice3_original = _ORIGINAL_SHELLINGHAM_DETECT  # pyright: ignore[reportFunctionMemberAccess]
    _detect_shell_for_completion._pymobiledevice3_xonsh_patched = True  # pyright: ignore[reportFunctionMemberAccess]
    shellingham.detect_shell = _detect_shell_for_completion


_patch_xonsh_completion_detection()


class Pmd3TyperGroup(TyperGroup):
    # Typer vendors click privately (typer._click) and exposes no public alias for the runtime
    # Command/Context classes, so click-typed parameters are annotated `Any` to stay on public API.
    def list_commands(self, ctx: Any) -> list[str]:
        # Order is preserved by dict insertion; adjust if you want alphabetical
        return list(CLI_GROUPS.keys())

    def get_command(self, ctx: Any, cmd_name: str):
        if cmd_name not in CLI_GROUPS:
            self.handle_invalid_command(ctx, cmd_name)
        return self.import_and_get_command(ctx, cmd_name)

    def handle_invalid_command(self, ctx: Any, name: str) -> None:
        suggested_commands = self.search_commands(name)
        suggestion = self.format_suggestions(suggested_commands)
        # ctx.fail raises a ClickException underneath, which Typer displays nicely
        ctx.fail(f"No such command {name!r}{suggestion}")

    @staticmethod
    def format_suggestions(suggestions: list[str]) -> str:
        if not suggestions:
            return ""
        cmds = textwrap.indent("\n".join(suggestions), " " * 4)
        return f"\nDid you mean:\n{cmds}"

    @staticmethod
    def import_and_get_command(ctx: Any, name: str):
        module_name = f"pymobiledevice3.cli.{CLI_GROUPS[name]}"
        mod = importlib.import_module(module_name)
        # submodules expose a Typer Group named "cli"
        cli: typer.Typer = mod.cli
        command = typer.main.get_command(cli)
        # A collapsed single-command module keeps its inner command's click name
        # (e.g. btlogger's "capture"), but help and suggestions render that name
        # while dispatch goes by the CLI_GROUPS key — so align it.
        command.name = name
        return command

    @staticmethod
    def highlight_keyword(text: str, keyword: str) -> str:
        return re.sub(f"({keyword})", typer.style("\\1", bold=True), text, flags=re.IGNORECASE)

    @staticmethod
    def collect_commands(command: Any) -> Union[str, list[str]]:
        if isinstance(command, TyperGroup):  # group
            cmds: list[str] = []
            for v in command.commands.values():
                child = Pmd3TyperGroup.collect_commands(v)
                if isinstance(child, list):
                    cmds.extend([f"{command.name} {c}" for c in child])
                else:
                    cmds.append(f"{command.name} {child}")
            return cmds
        return command.name or ""

    @staticmethod
    def search_commands(pattern: str) -> list[str]:
        all_commands = Pmd3TyperGroup.load_all_commands()
        matched = sorted(filter(lambda cmd: re.search(pattern, cmd), all_commands))
        if not matched:
            matched = difflib.get_close_matches(pattern, all_commands, n=20, cutoff=0.4)
        if isatty():
            matched = [Pmd3TyperGroup.highlight_keyword(cmd, pattern) for cmd in matched]
        return matched

    @staticmethod
    def load_all_commands() -> list[str]:
        all_commands: list[str] = []
        for key in CLI_GROUPS:
            module_name = f"pymobiledevice3.cli.{CLI_GROUPS[key]}"
            mod = importlib.import_module(module_name)
            if isinstance(mod.cli, typer.Typer):
                # Resolve like import_and_get_command does: a single-command module
                # with no callback collapses into one command invoked by the group key.
                cmd = Pmd3TyperGroup.collect_commands(typer.main.get_command(mod.cli))
                if not isinstance(cmd, list):
                    cmd = key
            else:
                cmd = Pmd3TyperGroup.collect_commands(mod.cli.commands[key])
            if isinstance(cmd, list):
                all_commands.extend(cmd)
            else:
                all_commands.append(cmd)
        return all_commands


app = InjectingTyper(
    cls=Pmd3TyperGroup,
    context_settings=CONTEXT_SETTINGS,
    no_args_is_help=True,
    # add_completion=False,
    rich_markup_mode="markdown",
    help=(
        "Swiss-army CLI for pairing, inspecting, backing up, and automating iOS devices.\n\n"
        "Docs and examples: https://github.com/doronz88/pymobiledevice3"
    ),
)


@app.callback()
def _root(
    reconnect: Annotated[
        bool,
        typer.Option(
            "--reconnect",
            help=(
                "Automatically reconnect if the device disconnects mid-command "
                f"(set {RECONNECT_ANY_ENV_VAR} to accept any device, not just the original one)."
            ),
            show_default=False,
        ),
    ] = False,
    verbosity: Annotated[
        int,
        typer.Option(
            "--verbose",
            "-v",
            count=True,
            help="Increase logging verbosity (repeat for more detail).",
        ),
    ] = 0,
    color: Annotated[
        bool,
        typer.Option(help="Colorize output; disable with --no-color for plain logs."),
    ] = True,
) -> None:
    """
    Top-level options for pymobiledevice3.
    """
    global RECONNECT
    RECONNECT = reconnect
    set_verbosity(verbosity)
    set_color_flag(color)


def product_version_needs_tunnel(product_version: str) -> bool:
    """True when the device's iOS version (>= 17.0) means a developer command needs an RSD tunnel."""
    return Version(product_version) >= Version("17.0")


def invoke_cli_with_error_handling() -> tuple[ExitCode, bool]:
    """
    Invoke the command line interface once. Returns (exit_code, reconnectable) - reconnectable is
    True when the failure was that the device disconnected, which keeps the `--reconnect` retry
    loop alive. A successful command never reaches this function's own return statements: it
    exits earlier, via the SystemExit that Typer's own `app(...)` call raises.
    """
    reconnectable = False
    try:
        # Typer apps are callable; this executes the CLI with current sys.argv
        app(args=["--help"] if len(sys.argv) == 1 else None)
    except NoDeviceConnectedError:
        logger.error("Device is not connected")
        reconnectable = True
    except ConnectionTerminatedError:
        logger.error("Connection was terminated abruptly")
        reconnectable = True
    except NotPairedError:
        logger.error("Device is not paired")
    except UserDeniedPairingError:
        logger.error("User refused to trust this computer")
    except PairingDialogResponsePendingError:
        logger.error("Waiting for user dialog approval")
    except SetProhibitedError:
        logger.error("lockdownd denied the access")
    except MissingValueError:
        logger.error("No such value")
    except DeviceHasPasscodeSetError:
        logger.error("Cannot enable developer-mode when passcode is set")
    except DeveloperModeError:
        logger.error("Failed to enable developer-mode.")
    except ConnectionFailedToUsbmuxdError:
        logger.error("Failed to connect to usbmuxd socket. Make sure it's running.")
    except ConnectionFailedError:
        logger.error("Failed to connect to service port.")
        reconnectable = True
    except MessageNotSupportedError:
        logger.error("Message not supported for this iOS version")
        traceback.print_exc()
    except InternalError as e:
        # surface the device's DetailedError (e.g. "Failed to unload launchd jobs" on unmount)
        response = cast(dict[str, Any], e.args[0]) if e.args and isinstance(e.args[0], dict) else {}
        detail = str(response.get("DetailedError", ""))
        logger.error(f"Internal Error: {detail}" if detail else "Internal Error")
    except DeveloperModeIsNotEnabledError:
        logger.error(
            "Developer Mode is disabled. You can try to enable it using: "
            "python3 -m pymobiledevice3 amfi enable-developer-mode"
        )
    except RoutableTunnelRequiredError as e:
        logger.error(str(e))
    except DeviceNotFoundError as e:
        # The message names the lookup that failed (usbmux/tunneld/remotepairingd/...).
        logger.error(str(e))
        # Reconnectable: after a disconnect the target device may still be re-enumerating
        # while other devices are attached, making re-invocation fail with this error.
        reconnectable = True
    except UserspaceTunnelUnavailableError as e:
        logger.error(str(e))
    except DeviceFeatureNotSupportedError as e:
        logger.error(f"{e} (iOS {e.product_version})")
    except (InvalidServiceError, RSDRequiredError) as e:
        reason = ""
        # Both exceptions carry the device's product version (no extra device round-trip needed).
        product_version = e.product_version
        if isinstance(e, RSDRequiredError):
            reason = "RSD is required for this command"
        elif (
            (e.identifier is not None)
            and ("developer" in sys.argv)
            and ("--tunnel" not in sys.argv)
            and ("--userspace" not in sys.argv)
            and ("--native" not in sys.argv)
            and product_version_needs_tunnel(product_version)
        ):
            reason = "it is a developer command on an iOS 17+ device"
        # Retry once, establishing the default RSD chain in-process (see make_rsd_dependency): the
        # preferred transport is chosen by default_transport_preference() (native on macOS, else
        # userspace; PYMOBILEDEVICE3_DEFAULT_FALLBACK overrides) and falls back through the other
        # no-root path and tunneld as needed. FORCE_TUNNEL_ENV_VAR both requests this and guards
        # against looping; an explicit transport env means the user already chose one, so don't retry.
        if (
            reason
            and not os.getenv(USERSPACE_ENV_VAR)
            and not os.getenv(TUNNEL_ENV_VAR)
            and not os.getenv(NATIVE_ENV_VAR)
            and not os.getenv(FORCE_TUNNEL_ENV_VAR)
        ):
            preferred = {
                "native": "the native tunnel",
                "userspace": "a no-root userspace tunnel",
                "tunneld": "tunneld",
            }[default_transport_preference()]
            logger.warning(
                f"Trying again over {preferred} since {reason} "
                "(override with PYMOBILEDEVICE3_DEFAULT_FALLBACK, or --tunnel/--userspace/--native)"
            )
            os.environ[FORCE_TUNNEL_ENV_VAR] = "1"
            # Target the same device the tunnel would otherwise resolve by default.
            if e.identifier and not os.getenv(UDID_ENV_VAR):
                os.environ[UDID_ENV_VAR] = e.identifier
            # main() only returns (rather than raising the SystemExit(0) a successful retry ends
            # in) when the retried attempt also failed - propagate its actual exit code (e.g.
            # ExitCode.ABORTED on Ctrl-C) instead of flattening it to a generic error.
            exit_code = main()
            return exit_code, False
        logger.error(INVALID_SERVICE_MESSAGE)
    except PasswordRequiredError:
        logger.error("Device is password protected. Please unlock and retry")
    except AccessDeniedError:
        logger.error(get_os_utils().access_denied_error)
    except BrokenPipeError:
        traceback.print_exc()
    except TunneldConnectionError:
        logger.error(
            "Unable to connect to Tunneld. You can start one using:\nsudo python3 -m pymobiledevice3 remote tunneld"
        )
    except DeprecationError:
        logger.error("failed to query MobileGestalt, MobileGestalt deprecated (iOS >= 17.4).")
    except CoreDeviceError as e:
        # A CoreDevice invocation failed for a reason we can state plainly (e.g.
        # the camera/microphone is in use): print the message, no traceback.
        logger.error(str(e))
    except CryptexdError as e:
        logger.error(f"cryptexd rejected the request: {e}")
    except InstallCoordinationError as e:
        logger.error(f"install coordination request failed: {e}")
    except OSNotSupportedError as e:
        logger.error(
            f"Unsupported OS - {e.os_name}. To add support, consider contributing at "
            f"https://github.com/doronz88/pymobiledevice3."
        )
    except CloudConfigurationAlreadyPresentError:
        logger.error(
            "A cloud configuration is already present on device. You must first erase the device in order "
            "to install new one:\n"
            "> pymobiledevice3 profile erase-device"
        )
    except FeatureNotSupportedError as e:
        logger.error(
            f"Missing implementation of `{e.feature}` on `{e.os_name}`. To add support, consider contributing at "
            f"https://github.com/doronz88/pymobiledevice3."
        )
    except QuicProtocolNotSupportedError:
        logger.error("Encountered a QUIC protocol error.")
    except StartServiceError as e:
        if e.message == "ServiceProhibited" and e.service_name == "com.apple.pcapd.shim.remote":
            logger.error(
                f"The {e.service_name} service is USB only (at least for some iOS versions).\n"
                "Full discussion is available in: https://github.com/doronz88/pymobiledevice3/issues/1515"
            )
        else:
            logger.error(f"Failed to start: {e.service_name} with. Received error: {e.message}.")
    except AfcFileNotFoundError as e:
        logger.error(f"File [{e.filename}] not found during afc operation: {e}")
    except AfcException as e:
        logger.error(f"Failed to perform Afc operation: {e}")
    except DevicePathError as e:
        logger.error(f"Refusing a path supplied by the device: {e}")
    else:
        # No exception: in practice unreachable, since a real Typer app() raises SystemExit(0) on
        # success before ever returning here
        return ExitCode.SUCCESS, False
    return ExitCode.ERROR, reconnectable


def _retarget_reconnect_udid(udid: str) -> None:
    """Point the `--reconnect` re-invocation at ``udid``: an explicit ``--udid`` on argv wins over
    the env var, so rewrite both."""
    for i, arg in enumerate(sys.argv):
        if arg == "--udid" and i + 1 < len(sys.argv):
            sys.argv[i + 1] = udid
        elif arg.startswith("--udid="):
            sys.argv[i] = f"--udid={udid}"
    os.environ[UDID_ENV_VAR] = udid


def tolerate_unencodable_output() -> None:
    """Escape, instead of crash on, characters the console encoding cannot represent.

    Device-supplied text (syslog lines, process names, bundle names, ...) can carry any code point,
    while a Windows console frequently hands Python a cp1252 stdout. With the default
    `errors="strict"` a single emoji in a syslog line raises UnicodeEncodeError from inside print()
    (issue #1942). `backslashreplace` keeps the character recoverable (`\\U0001f600`) rather than
    dropping it, and matches what Python already does for stderr."""
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is not None:
            reconfigure(errors="backslashreplace")


def main() -> ExitCode:
    """Returns the process exit code. A successful command exits earlier via the SystemExit that
    Typer's own `app(...)` call raises, from within `invoke_cli_with_error_handling()`; this loop
    only ever runs again (or returns ExitCode.ABORTED) once that call has already logged an
    error."""
    tolerate_unencodable_output()
    while True:
        exit_code, reconnectable = invoke_cli_with_error_handling()
        # Not a reconnectable failure, or not invoked with `--reconnect`: stop here.
        if not reconnectable or not RECONNECT:
            return exit_code
        try:
            logger.info("Waiting for the device to be available again")
            # Wait for the device the command targeted, not just any device. The target is the
            # explicit --udid / env value, or whichever device the command's dependency resolved
            # to (auto-pick or interactive prompt). RECONNECT_ANY_ENV_VAR opts out: accept the
            # first available device even when its UDID differs from the original target.
            serial = _cli_udid() or resolved_udid()
            accept_any = bool(os.getenv(RECONNECT_ANY_ENV_VAR))
            if accept_any and serial is not None:
                logger.warning(
                    f"{RECONNECT_ANY_ENV_VAR} is set: accepting the first available device, "
                    f"even if its UDID differs from {serial}"
                )
            lockdown = asyncio.run(retry_create_using_usbmux(serial=None if accept_any else serial))
            if accept_any and lockdown.udid:
                if serial is not None and lockdown.udid != serial:
                    logger.warning(f"Reconnected to a different device: {lockdown.udid} (was {serial})")
                serial = lockdown.udid
                # Retarget the re-invocation at the device that actually connected.
                _retarget_reconnect_udid(serial)
            elif serial is not None and not os.getenv(UDID_ENV_VAR):
                # Stamp the target so the re-invocation resolves the same device instead of
                # prompting again (or silently auto-picking another attached device).
                os.environ[UDID_ENV_VAR] = serial
            logger.info("Device connected")
            asyncio.run(lockdown.close())
        except KeyboardInterrupt:
            print("Aborted.")
            return ExitCode.ABORTED


if __name__ == "__main__":
    sys.exit(main())
