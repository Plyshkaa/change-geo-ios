# Screen-mirror motion tear — findings

## The symptom

CoreDevice DisplayService (`com.apple.coredevice.displayservice`) streams the
device screen as RTP/HEVC over the utun tunnel; `serve-vnc` and `serve-web`
render it. Under heavy on-device motion the picture progressively **smears**:
icons stay legible but blocky garbage drifts across the frame and accumulates
over successive frames. Apple's Xcode **DeviceHub** "View Screen" renders the
identical device and motion with **no tear** — it is the reference target.

## What was discovered

Every plausible cause on the pymobiledevice3 side was eliminated, each proven,
and the differentiator was localized to Apple's own decoder process:

- **Not the encoder / bitrate / QP** — DeviceHub's encoder telemetry under the
  same hard motion matches ours (QP ~33/36, ~5.5 Mbps).
- **Not packet loss or reorder** — a capture of DeviceHub's own RTP is perfectly
  sequence-contiguous (15342 packets, zero gaps, zero reorder).
- **Not depacketization** — our RFC-7798 output is byte-identical to ffmpeg's,
  and a fresh correct re-depacketization of the RTP is byte-identical to the
  stream DeviceHub decoded.
- **Not the bytes / not bitstream patching** — `avconferenced`'s *actual* fed
  access units (dumped live from its decoder) are **byte-for-byte identical** to
  our depacketization of the concurrent RTP, for every frame compared.
- **Not keyframe requests** — the device ignores RTCP PLI for refresh; it honors
  FIR (PT=206 FMT=4, requires `allowRTCPFB`) and emits IDRs on request, but
  periodic IDR cannot outrun the drift. Neither removes the tear.
- **Not IDR cadence** — a confirmed-clean live session ran 1588 frames with zero
  IDRs; the smearing capture has a single IDR. Same regime, opposite result.
- **Not decoder configuration** — `avconferenced`'s complete decode config was
  captured and replayed exactly (see below) → identical smear.
- **Not HW vs SW decoder** — forcing Apple's software VideoToolbox decoder
  (verified the mode switched) → identical smear.
- **Not real-time pacing** — a 16.6 ms-paced feed produces the identical smear;
  decode of complete bytes is deterministic.

The one bitstream oddity found: DisplayService appends a **constant 14-byte
footer** (`04f00ac0000003000004ec0ab003`) after the final fragment of each
coded-slice NAL. `avconferenced` strips it before decode; a plain reassembly
would feed it as trailing slice data. It is **not** the cause (decoders ignore
trailing bytes after the slice data — stripping it does not change the decode)
but it is malformed, so the depacketizer now drops it.

### The decoder configuration that was captured and replayed

Captured from `avconferenced` and replayed verbatim against the smearing
stream — all reproduce the identical smear:

- Per-frame call `VTDecompressionSessionDecodeFrameWithOptions`, `flags=0x1`
  (async), options `{ActiveVideoResolution, CalculateYUVChecksum=0,
  ContentAnalyzerCropRectangle, ExtraInLoopChromaFilter=0}`.
- VCP create spec `{NegotiationDetails="VRAE:0;SW:1;FLS", NumberOfTiles=1}`.
- VCP-level properties `NegotiationDetails`, `DecoderUsage=0`, `FaceZoom=0`,
  `MLEnhance=0`, `MLVideoEnhance=0`, `Disable270MLScale=1` — all conferencing
  feature toggles, none touching reference handling or concealment.
- VT session properties `Rotation`, `EnableGPUAcceleratedTransfer=0`,
  `WriteBlackPixelsOutsideDestRect=1`, `ScalingMode=Trim`, thread-priority — all
  display/geometry.

There is no reference-management or error-concealment knob anywhere in it.

## How it was discovered

- **Wall-clock-aligned two-sided capture** — screen-recorded the DeviceHub
  window while capturing its RTP on the utun. Frames that are clean in the
  DeviceHub window at instant *T* smear when the exact concurrent bytes are
  decoded by every standalone decoder.
- **RTP sequence-continuity analysis** — parsed the raw RTP dump to prove zero
  packet loss (no sequence gaps, marker count = frame count).
- **lldb hardware breakpoints** on `avconferenced` — the tooling unlock:
  software breakpoints never fire on dyld-shared-cache functions, hardware ones
  do. Used to capture the exact per-frame decode call, its options dictionary,
  the `VTDecompressionSessionCreate`/`VCPDecompressionSessionCreate` spec, and
  every `VTSessionSetProperty` / `VCPDecompressionSessionSetProperty` call.
  (frida was rejected by AMFI library-validation even as root under SIP-off.)
- **Low-perturbation fed-AU dump** — an lldb Python breakpoint callback that
  auto-continues (never stops the target), copying each fed `CMSampleBuffer`'s
  bytes and `rtpTimestamp` out via CoreMedia, while a passive `tcpdump` captured
  the concurrent RTP. Byte-comparing the two proved the fed bytes are identical
  to our own depacketization — refuting the "Apple patches the bitstream" theory.
- **Replay harnesses** (Swift + Python) that reconstruct `avconferenced`'s exact
  VideoToolbox and VideoProcessing/VCP configuration and decode the captured
  stream — used to rule the whole config surface in/out.
- **Forced-decoder tests** — forced Apple's software HEVC decoder and verified
  (via the `UsingHardwareAcceleratedVideoDecoder` property) that the mode
  actually switched.
- **AVConference API + entitlement inspection** — enumerated the framework's
  classes: `VCVideoDecoder` has no decode-a-buffer method (it drives a
  transport-coupled `VCVideoPlayer` engine), and `avconferenced` carries no
  codec/decode-specific entitlement.

## Conclusions

- The motion tear is a **receiver-side decode phenomenon bound to
  `avconferenced`'s execution context** — not the bytes, the depacketization,
  packet loss, keyframe cadence, or any settable VideoToolbox/VideoProcessing
  property. The DisplayService HEVC stream is subtly non-conformant, and only
  Apple's in-process conferencing decode path (reached through a
  transport-coupled `VideoReceiver`/`VCVideoPlayer` engine) reconstructs it
  cleanly. Every decoder reachable from an ordinary process — VideoToolbox HW,
  VideoToolbox SW, VideoProcessing/VCP with Apple's exact spec, ffmpeg, browser
  WebCodecs — smears on the byte-identical stream.
- **A decode-only fix in pymobiledevice3 is not achievable.** Matching DeviceHub
  would require driving `avconferenced`'s own `VideoReceiver` pipeline, which
  exposes no standalone decode API and runs in Apple's process context.
- **Landed:** the 14-byte trailer strip in `depacketize_hevc` — bitstream
  correctness / parity with Apple's receiver, not a tear fix.

## Reproduce

Decode a captured Annex-B stream offline (any VideoToolbox or ffmpeg harness)
and inspect a late frame — it smears, while the DeviceHub window at the same
wall-clock instant is clean.

## Update (2026-09-16): the browser smear was encoder frame-dropping, keyed by `VRAE:0`

The negotiated codec feature-list string turned out to matter. Credit to
[@jkcoxson](https://github.com/jkcoxson): his `idevice` screen-stream offer
(`SCREEN_HEVC_FLS` in `display_stream/negotiation.rs`) was the first known
configuration without the smear, and diffing it against ours is what exposed
the token. Apple's captured
Xcode offer declares `FLS;VRAE:0;SW:1;` in the PT=100 bank, and that is what
pymobiledevice3 replayed. `VRAE` is AVConference's *video resolution
adaptation enabled* switch (`isVRAEnabled`, "Aligning VRA encoder resolution");
`VRAE:0` forbids the encoder from adapting resolution, so under the fixed
6 Mbps cap its remaining rate-control lever is dropping input frames.

Measured on iPhone18,4 / iOS 27.0 with the device's own `VCPEnc` telemetry
(`pymobiledevice3 syslog live -m VCPEnc`) over identical 20 s home-screen
page-swipe sequences driven in-process over HID:

| offered PT=100 features                          | negotiated        | drop_fps sum   | Tx_fps | Avg QP |
|--------------------------------------------------|-------------------|----------------|--------|--------|
| `FLS;VRAE:0;SW:1;` (old default)                 | `VRAE:0;SW:1;FLS` | 207-219 frames | ~42    | ~30    |
| `FLS;VRAE:0;`                                    | `FLS;VRAE:0`      | 207 frames     | 41     | 30     |
| `FLS;SW:1;` (new default)                        | `FLS;SW:1`        | 0              | 53     | 33     |
| `FLS;`                                           | `FLS`             | 0              | 52-55  | 33     |
| idevice string (`FLS;MS:-1;LF:-1;LTR;CABAC;...`) | `FLS`             | 0              | 55     | 33     |

The device intersects the offered token list with what it knows (`VRAE`,
`SW`); everything else is dropped silently, which is why the richer
third-party string "works" -- it simply no longer says `VRAE:0`. LTRP and FEC
do not change the drop count.

End to end, in Chrome via `serve-web` with the same swipe sequence and a 90 ms
canvas capture: the old string shows multi-frame mosaic episodes (one ~7-frame
episode in a 9 s run, ten separate episodes in a 14 s run at ~31 viewer fps);
`FLS;SW:1;` shows none across two runs (~91 and ~137 frames, 53-57 viewer
fps). The encoder keeps every frame at a slightly higher QP instead of dropping
some and then encoding a huge residual into the next one.

This supersedes the "decode-only fix is not achievable" conclusion above for
the motion smear: it was never a decoder problem, it was the offer.
