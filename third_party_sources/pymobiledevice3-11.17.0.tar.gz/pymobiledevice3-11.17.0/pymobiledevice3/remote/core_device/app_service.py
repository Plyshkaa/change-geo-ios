import plistlib
from collections.abc import AsyncIterator
from typing import Any, Optional

from pymobiledevice3.remote.core_device.core_device_service import CoreDeviceService
from pymobiledevice3.remote.remote_service_discovery import RemoteServiceDiscoveryService
from pymobiledevice3.remote.xpc_message import XpcInt64Type

FEATURE_LISTAPPS = "com.apple.coredevice.feature.listapps"
FEATURE_STREAMAPPLIST = "com.apple.coredevice.feature.streamapplist"


class AppServiceService(CoreDeviceService):
    """
    Manage applications
    """

    SERVICE_NAME = "com.apple.coredevice.appservice"

    def __init__(self, rsd: RemoteServiceDiscoveryService):
        super().__init__(rsd, self.SERVICE_NAME)

    async def list_apps(
        self,
        include_app_clips: bool = True,
        include_removable_apps: bool = True,
        include_hidden_apps: bool = True,
        include_internal_apps: bool = True,
        include_default_apps: bool = True,
        require_container_access: bool = False,
        include_app_group_identifiers: bool = False,
        include_container_paths: bool = False,
    ) -> list[dict[str, Any]]:
        """List applications.

        The streaming variant is preferred whenever the DDI advertises it: DDIs new enough to
        offer streamapplist (iOS 26 era) never reply to a well-formed non-streaming listapps
        request (and the stuck call wedges dtappserviced) — Xcode 26 uses streamapplist there
        too. Older DDIs advertise only listapps, which they answer fine.
        """
        arguments = {
            "includeAppClips": include_app_clips,
            "includeRemovableApps": include_removable_apps,
            "includeHiddenApps": include_hidden_apps,
            "includeInternalApps": include_internal_apps,
            "includeDefaultApps": include_default_apps,
            # Required since iOS 26 (InstalledAppsRequestParams). requireContainerAccess=True
            # needs the com.apple.private.CoreDevice.obtainContainerAccess entitlement.
            "requireContainerAccess": require_container_access,
            "includeAppGroupIdentifiers": include_app_group_identifiers,
            "includeContainerPaths": include_container_paths,
        }
        if FEATURE_STREAMAPPLIST in self.rsd.get_service_features(self.service_name):
            return [app async for app in self.stream_invoke(FEATURE_STREAMAPPLIST, arguments)]
        return await self.invoke(FEATURE_LISTAPPS, arguments)

    async def launch_application(
        self,
        bundle_id: str,
        arguments: Optional[list[str]] = None,
        kill_existing: bool = True,
        start_suspended: bool = False,
        environment: Optional[dict[str, str]] = None,
        extra_options: Optional[dict[str, Any]] = None,
    ) -> list[dict[str, Any]]:
        """launch application"""
        return await self.invoke(
            "com.apple.coredevice.feature.launchapplication",
            {
                "applicationSpecifier": {
                    "bundleIdentifier": {"_0": bundle_id},
                },
                "options": {
                    "arguments": arguments if arguments is not None else [],
                    "environmentVariables": environment if environment is not None else {},
                    "standardIOUsesPseudoterminals": True,
                    "startStopped": start_suspended,
                    "terminateExisting": kill_existing,
                    "user": {"shortName": "mobile"},
                    "platformSpecificOptions": plistlib.dumps(extra_options if extra_options is not None else {}),
                },
                "standardIOIdentifiers": {},
            },
        )

    async def list_processes(self) -> list[dict[str, Any]]:
        """List processes"""
        return (await self.invoke("com.apple.coredevice.feature.listprocesses"))["processTokens"]

    async def stream_apps(
        self,
        include_app_clips: bool = True,
        include_removable_apps: bool = True,
        include_hidden_apps: bool = True,
        include_internal_apps: bool = True,
        include_default_apps: bool = True,
        require_container_access: bool = False,
        include_app_group_identifiers: bool = False,
        include_container_paths: bool = False,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream the installed application list, yielding each app as it is pushed.

        Streaming counterpart of ``list_apps``; elements share the same shape.
        """
        async for app in self.stream_invoke(
            FEATURE_STREAMAPPLIST,
            {
                "includeAppClips": include_app_clips,
                "includeRemovableApps": include_removable_apps,
                "includeHiddenApps": include_hidden_apps,
                "includeInternalApps": include_internal_apps,
                "includeDefaultApps": include_default_apps,
                "requireContainerAccess": require_container_access,
                "includeAppGroupIdentifiers": include_app_group_identifiers,
                "includeContainerPaths": include_container_paths,
            },
        ):
            yield app

    async def stream_processes(self) -> AsyncIterator[dict[str, Any]]:
        """Stream the process list, yielding each process token as it is pushed.

        Streaming counterpart of ``list_processes``; elements share the same shape.
        """
        async for process in self.stream_invoke("com.apple.coredevice.feature.streamprocesslist"):
            yield process

    async def list_roots(self) -> dict[str, Any]:
        """
        List roots.

        Can only be performed on certain devices
        """
        return await self.invoke("com.apple.coredevice.feature.listroots", {"rootPoint": {"relative": "/"}})

    async def spawn_executable(self, executable: str, arguments: list[str]) -> dict[str, Any]:
        """
        Spawn given executable.

        Can only be performed on certain devices
        """
        return await self.invoke(
            "com.apple.coredevice.feature.spawnexecutable",
            {
                "executableItem": {
                    "url": {
                        "_0": {
                            "relative": executable,
                        },
                    }
                },
                "standardIOIdentifiers": {},
                "options": {
                    "arguments": arguments,
                    "environmentVariables": {},
                    "standardIOUsesPseudoterminals": True,
                    "startStopped": False,
                    "user": {
                        "active": True,
                    },
                    "platformSpecificOptions": plistlib.dumps({}),
                },
            },
        )

    async def monitor_process_termination(self, pid: int) -> dict[str, Any]:
        """
        Monitor process termination.

        Can only be performed on certain devices
        """
        return await self.invoke(
            "com.apple.coredevice.feature.monitorprocesstermination",
            {"processToken": {"processIdentifier": XpcInt64Type(pid)}},
        )

    async def uninstall_app(self, bundle_identifier: str) -> None:
        """
        Uninstall given application by its bundle identifier
        """
        await self.invoke("com.apple.coredevice.feature.uninstallapp", {"bundleIdentifier": bundle_identifier})

    async def send_signal_to_process(self, pid: int, signal: int) -> dict[str, Any]:
        """
        Send signal to given process by its pid
        """
        return await self.invoke(
            "com.apple.coredevice.feature.sendsignaltoprocess",
            {
                "process": {"processIdentifier": XpcInt64Type(pid)},
                "signal": XpcInt64Type(signal),
            },
        )
