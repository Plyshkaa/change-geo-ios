import asyncio
import struct
import time
import uuid
from collections.abc import AsyncGenerator
from enum import Enum, IntEnum
from typing import Any, Optional

from pymobiledevice3.exceptions import CoreDeviceError
from pymobiledevice3.remote.core_device.core_device_service import CoreDeviceService
from pymobiledevice3.remote.remote_service_discovery import RemoteServiceDiscoveryService
from pymobiledevice3.remote.xpc_message import XpcInt64Type, XpcUInt64Type

# Capability tags the control service advertises in the RSD handshake. These are NOT invoke()
# feature identifiers: the control service rejects the CoreDevice.featureIdentifier envelope with
# "The command provided by the client is not valid" (com.apple.dt.remoteservices.error 11014,
# verified on-device) and only speaks its Cmd-keyed session protocol below.
FEATURE_LIST_FILES = "com.apple.coredevice.feature.listFiles"
FEATURE_TRANSFER_FILES = "com.apple.coredevice.feature.transferFiles"


class Domain(IntEnum):
    APP_DATA_CONTAINER = 1
    APP_GROUP_DATA_CONTAINER = 2
    TEMPORARY = 3
    SYSTEM_CRASH_LOGS = 5

    @classmethod
    def from_name(cls, name: "DomainName") -> "Domain":
        return cls[name.name]


class DomainName(str, Enum):
    """Human-readable names for `Domain` (member names mirror it); resolve with `Domain.from_name()`."""

    APP_DATA_CONTAINER = "appDataContainer"
    APP_GROUP_DATA_CONTAINER = "appGroupDataContainer"
    TEMPORARY = "temporary"
    SYSTEM_CRASH_LOGS = "systemCrashLogs"


class FileServiceService(CoreDeviceService):
    """
    Filesystem control
    """

    CTRL_SERVICE_NAME = "com.apple.coredevice.fileservice.control"

    def __init__(self, rsd: RemoteServiceDiscoveryService, domain: Domain, identifier: str = "") -> None:
        super().__init__(rsd, self.CTRL_SERVICE_NAME)
        self.domain: Domain = domain
        self.session: Optional[str] = None
        self.identifier = identifier

    async def connect(self) -> None:
        await super().connect()
        response = await self.send_receive_request({
            "Cmd": "CreateSession",
            "Domain": XpcUInt64Type(self.domain),
            "Identifier": self.identifier,
            "Session": "",
            "User": "mobile",
        })
        self.session = response["NewSessionID"]

    async def retrieve_directory_list(self, path: str = ".") -> AsyncGenerator[list[str], None]:
        self.rsd.require_feature(self.CTRL_SERVICE_NAME, FEATURE_LIST_FILES)
        return (
            await self.send_receive_request({
                "Cmd": "RetrieveDirectoryList",
                "MessageUUID": str(uuid.uuid4()),
                "Path": path,
                "SessionID": self.session,
            })
        )["FileList"]

    async def retrieve_file(self, path: str = ".") -> bytes:
        self.rsd.require_feature(self.CTRL_SERVICE_NAME, FEATURE_TRANSFER_FILES)
        response = await self.send_receive_request({"Cmd": "RetrieveFile", "Path": path, "SessionID": self.session})
        data_service = self.rsd.get_service_port("com.apple.coredevice.fileservice.data")
        # Route through the RSD's dialer (set by the userspace tunnel to relay through its
        # in-process stack); falls back to the stdlib default for the kernel-tunnel path.
        open_connection = self.rsd.open_connection or asyncio.open_connection
        reader, writer = await open_connection(self.service.address[0], data_service)
        writer.write(b"rwb!FILE" + struct.pack(">QQQQ", response["Response"], 0, response["NewFileID"], 0))
        await writer.drain()
        await reader.readexactly(0x24)
        return await reader.readexactly(struct.unpack(">I", await reader.readexactly(4))[0])

    async def propose_empty_file(
        self,
        path: str = ".",
        file_permissions: int = 0o644,
        uid: int = 501,
        gid: int = 501,
        creation_time: float = time.time(),
        last_modification_time: float = time.time(),
    ) -> None:
        """Request to write an empty file at given path."""
        # Proposing a file is the write direction of the file-transfer flow.
        self.rsd.require_feature(self.CTRL_SERVICE_NAME, FEATURE_TRANSFER_FILES)
        await self.send_receive_request({
            "Cmd": "ProposeEmptyFile",
            "FileCreationTime": XpcInt64Type(creation_time),
            "FileLastModificationTime": XpcInt64Type(last_modification_time),
            "FilePermissions": XpcInt64Type(file_permissions),
            "FileOwnerUserID": XpcInt64Type(uid),
            "FileOwnerGroupID": XpcInt64Type(gid),
            "Path": path,
            "SessionID": self.session,
        })

    async def send_receive_request(self, request: dict[str, Any]) -> dict[str, Any]:
        response = await self.service.send_receive_request(request)
        encoded_error = response.get("EncodedError")
        if encoded_error is not None:
            localized_description = response.get("LocalizedDescription")
            if localized_description is not None:
                raise CoreDeviceError(localized_description)
            raise CoreDeviceError(encoded_error)
        return response
