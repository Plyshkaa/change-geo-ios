################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the Ethernet II packet header class.

pmd_net_proto/protocols/ethernet/ethernet__header.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from abc import ABC
from pmd_net_proto._compat import dataclass
from typing_extensions import Self, override

from pmd_net_addr import MacAddress
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.enums import EtherType
from pmd_net_proto.lib.proto_struct import ProtoStruct

# The Ethernet II packet header [DIX].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               >
# +    Destination MAC Address    +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# >                               |                               >
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+      Source MAC Address       +
# >                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |           EtherType           |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


ETHERNET__HEADER__LEN = 14
ETHERNET__HEADER__STRUCT = "! 6s 6s H"


@dataclass(frozen=True, kw_only=True, slots=True)
class EthernetHeader(ProtoStruct):
    """
    The Ethernet header.
    """

    dst: MacAddress
    src: MacAddress
    type: EtherType

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the Ethernet header fields.
        """

        assert isinstance(self.dst, MacAddress), f"The 'dst' field must be a MacAddress. Got: {type(self.dst)!r}"

        assert isinstance(self.src, MacAddress), f"The 'src' field must be a MacAddress. Got: {type(self.src)!r}"

        assert isinstance(self.type, EtherType), f"The 'type' field must be an EtherType. Got: {type(self.type)!r}"

    @override
    def __len__(self) -> int:
        """
        Get the Ethernet header length.
        """

        return ETHERNET__HEADER__LEN

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the Ethernet header as a memoryview.
        """

        struct.pack_into(
            ETHERNET__HEADER__STRUCT,
            buffer := bytearray(len(self)),
            0,
            bytes(self.dst),
            bytes(self.src),
            int(self.type),
        )

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the Ethernet header from buffer.
        """

        dst, src, type_ = struct.unpack(ETHERNET__HEADER__STRUCT, buffer[:ETHERNET__HEADER__LEN])

        return cls(
            dst=MacAddress(dst),
            src=MacAddress(src),
            type=EtherType.from_int(type_),
        )


class EthernetHeaderProperties(ABC):
    """
    Properties used to access Ethernet header fields.
    """

    _header: EthernetHeader

    @property
    def dst(self) -> MacAddress:
        """
        Get the Ethernet header 'dst' field.
        """

        return self._header.dst

    @dst.setter
    def dst(self, /, mac_address: MacAddress) -> None:
        """
        Set the Ethernet header 'dst' field.
        """

        # Hack to bypass the 'frozen=True' dataclass decorator.
        object.__setattr__(self._header, "dst", mac_address)

    @property
    def src(self) -> MacAddress:
        """
        Get the Ethernet header 'src' field.
        """

        return self._header.src

    @src.setter
    def src(self, /, mac_address: MacAddress) -> None:
        """
        Set the Ethernet header 'src' field.
        """

        # Hack to bypass the 'frozen=True' dataclass decorator.
        object.__setattr__(self._header, "src", mac_address)

    @property
    def type(self) -> EtherType:
        """
        Get the Ethernet header 'type' field.
        """

        return self._header.type
