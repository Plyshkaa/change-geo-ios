################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the ICMPv6 MLDv2 Multicast Address Record support class.

pmd_net_proto/protocols/icmp6/message/mld2/icmp6__mld2__multicast_address_record.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from dataclasses import field
from pmd_net_proto._compat import as_buffer, dataclass
from typing_extensions import Self, override

from pmd_net_addr import IP6__ADDRESS_LEN, Ip6Address
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.int_checks import is_4_byte_alligned
from pmd_net_proto.lib.proto_enum import ProtoEnumByte
from pmd_net_proto.lib.proto_struct import ProtoStruct

# The ICMPv6 MLDv2 Multicast Address Record [RFC 3810].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |  Record Type  |  Aux Data Len |     Number of Sources (N)     |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                       Multicast Address                       +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                       Source Address [1]                      +
# |                                                               |
# +                                                               +
# |                                                               |
# +---------------------------------------------------------------+
# |                                                               |
# +                                                               +
# |                                                               |
# +                       Source Address [2]                      +
# |                                                               |
# +                                                               +
# |                                                               |
# +---------------------------------------------------------------+
# .                               .                               .
# .                               .                               .
# .                               .                               .
# +---------------------------------------------------------------+
# |                                                               |
# +                                                               +
# |                                                               |
# +                       Source Address [N]                      +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# ~                                                               ~
# ~                         Auxiliary Data                        ~
# ~                                                               ~
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

# NOTE: The 'Aux Data Len' field is the length of the 'Auxiliary Data'
# field in 32-bit words.

ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN = 20
ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__STRUCT = "! BBH 16s"


class Icmp6Mld2MulticastAddressRecordType(ProtoEnumByte):
    """
    The ICMPv6 MLDv2 Multicast Address Record 'type' field values.
    """

    MODE_IS_INCLUDE = 1  # RFC 3810 §5.2.12: current-state record, INCLUDE filter mode.
    MODE_IS_EXCLUDE = 2  # RFC 3810 §5.2.12: current-state record, EXCLUDE filter mode.
    CHANGE_TO_INCLUDE = 3  # RFC 3810 §5.2.12: filter-mode change record, transition to INCLUDE.
    CHANGE_TO_EXCLUDE = 4  # RFC 3810 §5.2.12: filter-mode change record, transition to EXCLUDE.
    ALLOW_NEW_SOURCES = 5  # RFC 3810 §5.2.12: source-list change record, allow listed sources.
    BLOCK_OLD_SOURCES = 6  # RFC 3810 §5.2.12: source-list change record, block listed sources.


@dataclass(frozen=True, kw_only=True, slots=True)
class Icmp6Mld2MulticastAddressRecord(ProtoStruct):
    """
    The ICMPv6 MLDv2 Multicast Address Record.
    """

    type: Icmp6Mld2MulticastAddressRecordType
    # The 'aux_data_len' field is available as a property.
    # The 'number_of_sources' field is available as a property.
    multicast_address: Ip6Address
    source_addresses: list[Ip6Address] = field(default_factory=list[Ip6Address])
    aux_data: bytes = bytes()

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the ICMPv6 MLDv2 Multicast Address Record fields.
        """

        assert (
            self.multicast_address.is_multicast
        ), f"The 'multicast_address' field must be a multicast address. Got: {self.multicast_address!r}"

        for address in self.source_addresses:
            assert (
                address.is_unicast
            ), f"The 'source_addresses' field must contain only unicast addresses. Got: {address!r}"

        assert is_4_byte_alligned(
            len(self.aux_data)
        ), f"The 'aux_data' field must be 4-byte aligned. Got: {len(self.aux_data)!r}"

    @override
    def __len__(self) -> int:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record length.
        """

        return (
            ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN + IP6__ADDRESS_LEN * self.number_of_sources + self.aux_data_len
        )

    @override
    def __str__(self) -> str:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record log string.
        """

        sources_part = (
            ", sources (" + ", ".join(str(addr) for addr in self.source_addresses) + ")"
            if self.source_addresses
            else ""
        )
        aux_part = f", aux data {self.aux_data!r}" if self.aux_data else ""

        return f"[type '{self.type}', addr {self.multicast_address}{sources_part}{aux_part}]"

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record as a memoryview.
        """

        struct.pack_into(
            ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__STRUCT,
            buffer := bytearray(as_buffer(ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN)),
            0,
            int(self.type),
            self.aux_data_len >> 2,
            self.number_of_sources,
            bytes(self.multicast_address),
        )

        for source_address in self.source_addresses:
            buffer += bytearray(as_buffer(source_address))

        buffer += as_buffer(self.aux_data)

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    def __hash__(self) -> int:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record hash.
        """

        return hash(
            (
                self.type,
                self.multicast_address,
                tuple(self.source_addresses),
                self.aux_data,
            )
        )

    @property
    def number_of_sources(self) -> int:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record 'number_of_sources' field.
        """

        return len(self.source_addresses)

    @property
    def aux_data_len(self) -> int:
        """
        Get the ICMPv6 MLDv2 Multicast Address Record 'aux_data_len' field.
        """

        return len(self.aux_data)

    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the ICMPv6 MLDv2 Multicast Address Record from buffer.
        """

        type_, aux_data_len, number_of_sources, multicast_address = struct.unpack(
            ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__STRUCT,
            buffer[0:ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN],
        )

        source_addresses = [
            Ip6Address(
                buffer[
                    ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN
                    + IP6__ADDRESS_LEN * n : ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN
                    + IP6__ADDRESS_LEN * (n + 1)
                ]
            )
            for n in range(number_of_sources)
        ]

        aux_data_offset = ICMP6__MLD2__MULTICAST_ADDRESS_RECORD__LEN + IP6__ADDRESS_LEN * number_of_sources
        aux_data = bytes(buffer[aux_data_offset : aux_data_offset + (aux_data_len << 2)])

        return cls(
            type=Icmp6Mld2MulticastAddressRecordType.from_int(type_),
            multicast_address=Ip6Address(multicast_address),
            source_addresses=source_addresses,
            aux_data=aux_data,
        )
