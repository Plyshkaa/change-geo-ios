################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the ICMPv6 ND Pi (Prefix Information) option support code.

pmd_net_proto/protocols/icmp6/message/nd/option/icmp6__nd__option__pi.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from dataclasses import field
from pmd_net_proto._compat import dataclass
from typing_extensions import Self, override

from pmd_net_addr import Ip6Address, Ip6Mask, Ip6Network
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.int_checks import is_uint32
from pmd_net_proto.protocols.icmp6.icmp6__errors import Icmp6IntegrityError
from pmd_net_proto.protocols.icmp6.message.nd.option.icmp6__nd__option import (
    ICMP6__ND__OPTION__LEN,
    Icmp6NdOption,
    Icmp6NdOptionType,
)

# The ICMPv6 ND Pi (Prefix Information) option [RFC 4861].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |     Type      |    Length     | Prefix Length |L|A|R|    0    |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                         Valid Lifetime                        |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                       Preferred Lifetime                      |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                               0                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                                                               |
# +                                                               +
# |                                                               |
# +                            Prefix                             +
# |                                                               |
# +                                                               +
# |                                                               |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

ICMP6__ND__OPTION__PI__LEN = 32
ICMP6__ND__OPTION__PI__STRUCT = "! BB BB L L L 16s"


@dataclass(frozen=True, kw_only=True, slots=True)
class NdPrefixInfo:
    """
    The Neighbor Discovery Prefix Information data.
    """

    flag_l: bool
    flag_a: bool
    flag_r: bool
    valid_lifetime: int
    preferred_lifetime: int
    prefix: Ip6Network


@dataclass(frozen=True, kw_only=True, slots=True)
class Icmp6NdOptionPi(Icmp6NdOption):
    """
    The ICMPv6 ND Pi option support class.
    """

    type: Icmp6NdOptionType = field(
        repr=False,
        init=False,
        default=Icmp6NdOptionType.PI,
    )
    len: int = field(
        repr=False,
        init=False,
        default=ICMP6__ND__OPTION__PI__LEN,
    )

    flag_l: bool = False
    flag_a: bool = False
    flag_r: bool = False
    valid_lifetime: int
    preferred_lifetime: int
    prefix: Ip6Network

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the ICMPv6 ND Pi option fields.
        """

        assert isinstance(self.flag_l, bool), f"The 'flag_l' field must be a boolean. Got: {type(self.flag_l)!r}"

        assert isinstance(self.flag_a, bool), f"The 'flag_a' field must be a boolean. Got: {type(self.flag_a)!r}"

        assert isinstance(self.flag_r, bool), f"The 'flag_r' field must be a boolean. Got: {type(self.flag_r)!r}"

        assert is_uint32(
            self.valid_lifetime
        ), f"The 'valid_lifetime' field must be a 32-bit unsigned integer. Got: {self.valid_lifetime!r}"

        assert is_uint32(
            self.preferred_lifetime
        ), f"The 'preferred_lifetime' field must be a 32-bit unsigned integer. Got: {self.preferred_lifetime!r}"

        assert isinstance(
            self.prefix, Ip6Network
        ), f"The 'prefix' field must be an Ip6Network. Got: {type(self.prefix)!r}"

    @override
    def __str__(self) -> str:
        """
        Get the ICMPv6 ND Pi option log string.
        """

        return (
            f"prefix_info (prefix {self.prefix}, flags "
            f"{'L' if self.flag_l else '-'}"
            f"{'A' if self.flag_a else '-'}"
            f"{'R' if self.flag_r else '-'}, "
            f"valid_lifetime {self.valid_lifetime}, "
            f"preferred_lifetime {self.preferred_lifetime})"
        )

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the ICMPv6 ND Pi option as a memoryview.
        """

        struct.pack_into(
            ICMP6__ND__OPTION__PI__STRUCT,
            buffer := bytearray(len(self)),
            0,
            int(self.type),
            self.len >> 3,
            len(self.prefix.mask),
            (self.flag_l << 7) | (self.flag_a << 6) | (self.flag_r << 5),
            self.valid_lifetime,
            self.preferred_lifetime,
            0,
            bytes(self.prefix.address),
        )

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @staticmethod
    def _validate_integrity(buffer: Buffer, /) -> None:
        """
        Ensure integrity of the ICMPv6 ND Pi option before parsing it.
        """

        if (value := buffer[1] << 3) != ICMP6__ND__OPTION__PI__LEN:
            raise Icmp6IntegrityError(
                f"The ICMPv6 ND Pi option length value must be {ICMP6__ND__OPTION__PI__LEN} " f"bytes. Got: {value!r}"
            )

        if (value := buffer[1] << 3) > len(buffer):
            raise Icmp6IntegrityError(
                "The ICMPv6 ND Pi option length value must be less than or equal to the "
                f"length of provided bytes ({len(buffer)}). Got: {value!r}"
            )

    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the ICMPv6 ND Pi option from buffer.
        """

        assert (value := len(buffer)) >= ICMP6__ND__OPTION__LEN, (
            f"The minimum length of the ICMPv6 ND Pi option must be " f"{ICMP6__ND__OPTION__LEN} bytes. Got: {value!r}"
        )

        assert (value := buffer[0]) == int(Icmp6NdOptionType.PI), (
            f"The ICMPv6 ND Pi option type must be {Icmp6NdOptionType.PI!r}. "
            f"Got: {Icmp6NdOptionType.from_int(value)!r}"
        )

        cls._validate_integrity(buffer)

        (
            _,
            _,
            prefix_len,
            flags,
            valid_lifetime,
            preferred_lifetime,
            _,
            prefix,
        ) = struct.unpack(ICMP6__ND__OPTION__PI__STRUCT, buffer[:ICMP6__ND__OPTION__PI__LEN])

        return cls(
            flag_l=bool(flags & 0b10000000),
            flag_a=bool(flags & 0b01000000),
            flag_r=bool(flags & 0b00100000),
            valid_lifetime=valid_lifetime,
            preferred_lifetime=preferred_lifetime,
            prefix=Ip6Network((Ip6Address(prefix), Ip6Mask(f"/{prefix_len}"))),
        )
