################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the IPv6 Frag header.

pmd_net_proto/protocols/ip6_frag/ip6_frag__header.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from abc import ABC
from pmd_net_proto._compat import dataclass
from typing_extensions import Self, override

from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.enums import IpProto
from pmd_net_proto.lib.int_checks import is_8_byte_alligned, is_uint13, is_uint32
from pmd_net_proto.lib.proto_struct import ProtoStruct

# The IPv6 packet Fragmentation Extension header [RFC 8200].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# | Next Header   |       0       |         Offset          |0|0|M|
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                               Id                              |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+


IP6_FRAG__HEADER__LEN = 8
IP6_FRAG__HEADER__STRUCT = "! BBH L"


@dataclass(frozen=True, kw_only=True, slots=True)
class Ip6FragHeader(ProtoStruct):
    """
    The IPv6 Frag header.
    """

    next: IpProto
    offset: int
    flag_mf: bool
    id: int

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the IPv6 Frag header fields.
        """

        assert isinstance(self.next, IpProto), f"The 'next' field must be an IpProto. Got: {type(self.next)!r}"

        assert is_uint13(
            self.offset >> 3
        ), f"The 'offset' field must be a 13-bit unsigned integer (in 8-byte units). Got: {self.offset!r}"

        assert is_8_byte_alligned(self.offset), f"The 'offset' field must be 8-byte aligned. Got: {self.offset!r}"

        assert isinstance(self.flag_mf, bool), f"The 'flag_mf' field must be a boolean. Got: {type(self.flag_mf)!r}"

        assert is_uint32(self.id), f"The 'id' field must be a 32-bit unsigned integer. Got: {self.id!r}"

    @override
    def __len__(self) -> int:
        """
        Get the IPv6 Frag header length.
        """

        return IP6_FRAG__HEADER__LEN

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the IPv6 Frag header as a memoryview.
        """

        struct.pack_into(
            IP6_FRAG__HEADER__STRUCT,
            buffer := bytearray(len(self)),
            0,
            int(self.next),
            0,
            self.offset | self.flag_mf,
            self.id,
        )

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the IPv6 Frag header from buffer.
        """

        next, _, offset__flag_mf, id = struct.unpack(IP6_FRAG__HEADER__STRUCT, buffer[:IP6_FRAG__HEADER__LEN])

        return cls(
            next=IpProto.from_int(next),
            offset=offset__flag_mf & 0b11111111_11111000,
            flag_mf=bool(offset__flag_mf & 0b00000000_00000001),
            id=id,
        )


class Ip6FragHeaderProperties(ABC):
    """
    Properties used to access the IPv6 Frag header fields.
    """

    _header: Ip6FragHeader

    @property
    def next(self) -> IpProto:
        """
        Get the IPv6 Frag header 'next' field.
        """

        return self._header.next

    @property
    def offset(self) -> int:
        """
        Get the IPv6 Frag header 'offset' field.
        """

        return self._header.offset

    @property
    def flag_mf(self) -> bool:
        """
        Get the IPv6 Frag header 'flag_mf' field.
        """

        return self._header.flag_mf

    @property
    def id(self) -> int:
        """
        Get the IPv6 Frag header 'id' field.
        """

        return self._header.id
