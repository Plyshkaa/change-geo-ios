################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the IGMPv2 Membership Report message support class.

pmd_net_proto/protocols/igmp/message/igmp__message__v2_report.py

ver 3.0.7
"""

from __future__ import annotations

import struct
from dataclasses import field
from pmd_net_proto._compat import as_buffer, dataclass
from typing_extensions import Self, override

from pmd_net_addr import Ip4Address
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.int_checks import is_uint16
from pmd_net_proto.protocols.igmp.igmp__errors import (
    IgmpIntegrityError,
    IgmpSanityError,
)
from pmd_net_proto.protocols.igmp.message.igmp__message import (
    IgmpMessage,
    IgmpType,
)

# The IGMPv2 Membership Report message (0x16) [RFC 2236 §2].

# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# | Type = 0x16   | Max Resp Time |           Checksum            |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
# |                         Group Address                         |
# +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
#
# The Max Resp Time octet is meaningful only in Queries; in a Report
# it is set to zero by the sender and ignored on receipt (RFC 2236
# §2.2).

IGMP__V2_REPORT__LEN = 8
IGMP__V2_REPORT__STRUCT = "! BBH 4s"


@dataclass(frozen=True, kw_only=True, slots=True)
class IgmpMessageV2Report(IgmpMessage):
    """
    The IGMPv2 Membership Report message.
    """

    type: IgmpType = field(
        repr=False,
        init=False,
        default=IgmpType.V2_MEMBERSHIP_REPORT,
    )
    cksum: int = 0
    group_address: Ip4Address = Ip4Address()

    @override
    def __post_init__(self) -> None:
        """
        Ensure integrity of the IGMPv2 Membership Report message fields.
        """

        assert is_uint16(self.cksum), f"The 'cksum' field must be a 16-bit unsigned integer. Got: {self.cksum}"

    @override
    def __len__(self) -> int:
        """
        Get the IGMPv2 Membership Report message length.
        """

        return IGMP__V2_REPORT__LEN

    @override
    def __str__(self) -> str:
        """
        Get the IGMPv2 Membership Report message log string.
        """

        return f"IGMPv2 Membership Report group {self.group_address}"

    @override
    def __buffer__(self, _: int) -> memoryview:
        """
        Get the IGMPv2 Membership Report message as a memoryview, with
        the checksum slot left zero for the IGMP base to inject.
        """

        struct.pack_into(
            IGMP__V2_REPORT__STRUCT,
            buffer := bytearray(as_buffer(IGMP__V2_REPORT__LEN)),
            0,
            int(self.type),
            0,
            0,
            bytes(self.group_address),
        )

        return memoryview(buffer)
    @override
    def __bytes__(self) -> bytes:
        """
        Get the object as bytes (Python 3.9+ fallback for the
        PEP 688 '__buffer__' protocol, which is 3.12+).
        """

        return bytes(self.__buffer__(0))


    @override
    def validate_sanity(self) -> None:
        """
        Ensure sanity of the IGMPv2 Membership Report message after
        parsing it.
        """

        # RFC 2236 §2.4 — the Group Address field holds the IP multicast
        # group being reported, so a non-multicast group is invalid.
        if not self.group_address.is_multicast:
            raise IgmpSanityError(f"The 'group_address' field must be a multicast address. Got: {self.group_address!r}")

    @override
    @staticmethod
    def validate_integrity(*, frame: Buffer, ip4__payload_len: int) -> None:
        """
        Ensure integrity of the IGMPv2 Membership Report message before
        parsing it.
        """

        # RFC 2236 §2.5 — a message may be longer than 8 octets; only
        # the first 8 are processed (the rest stay checksum-covered).
        if not (IGMP__V2_REPORT__LEN <= ip4__payload_len <= len(frame)):
            raise IgmpIntegrityError(
                "The condition 'IGMP__V2_REPORT__LEN <= ip4__payload_len <= len(frame)' is not met. "
                f"Got: {IGMP__V2_REPORT__LEN=}, {ip4__payload_len=}, {len(frame)=}"
            )

    @override
    @classmethod
    def from_buffer(cls, buffer: Buffer, /) -> Self:
        """
        Initialize the IGMPv2 Membership Report message from buffer.
        """

        type_, _, cksum, group_bytes = struct.unpack(IGMP__V2_REPORT__STRUCT, buffer[:IGMP__V2_REPORT__LEN])

        assert (received_type := IgmpType.from_int(type_)) == (
            valid_type := IgmpType.V2_MEMBERSHIP_REPORT
        ), f"The 'type' field must be {valid_type!r}. Got: {received_type!r}"

        return cls(cksum=cksum, group_address=Ip4Address(bytes(group_bytes)))

    @override
    def assemble(self, buffers: list[Buffer], /) -> None:
        """
        Assemble the IGMPv2 Membership Report message into the buffer list.
        """

        buffers.append(as_buffer(bytearray(memoryview(as_buffer(self)))))
