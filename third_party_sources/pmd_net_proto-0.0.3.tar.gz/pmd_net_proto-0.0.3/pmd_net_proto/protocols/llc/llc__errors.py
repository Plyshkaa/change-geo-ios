################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the LLC protocol error classes.

pmd_net_proto/protocols/llc/llc__errors.py

ver 3.0.7
"""

from __future__ import annotations

from typing_extensions import override

from pmd_net_proto.lib.errors import PacketIntegrityError, PacketSanityError


class LlcIntegrityError(PacketIntegrityError):
    """
    Exception raised when LLC packet integrity check fails.
    """

    @override
    def __init__(self, message: str, /) -> None:
        super().__init__("[LLC] " + message)


class LlcSanityError(PacketSanityError):
    """
    Exception raised when LLC packet sanity check fails.
    """

    @override
    def __init__(self, message: str, /) -> None:
        super().__init__("[LLC] " + message)
