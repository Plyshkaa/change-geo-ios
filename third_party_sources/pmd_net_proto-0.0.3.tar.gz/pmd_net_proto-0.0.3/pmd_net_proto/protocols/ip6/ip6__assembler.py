################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the IPv6 packet assembler.

pmd_net_proto/protocols/ip6/ip6__assembler.py

ver 3.0.7
"""

from __future__ import annotations

from typing_extensions import override

from pmd_net_addr import Ip6Address
from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.enums import IpProto
from pmd_net_proto.lib.proto_assembler import ProtoAssembler
from pmd_net_proto.protocols.icmp6.icmp6__assembler import Icmp6Assembler
from pmd_net_proto.protocols.ip6.ip6__base import Ip6, Ip6Payload
from pmd_net_proto.protocols.ip6.ip6__header import (
    IP6__DEFAULT_HOP_LIMIT,
    Ip6Header,
)
from pmd_net_proto.protocols.raw.raw__assembler import RawAssembler
from pmd_net_proto.protocols.tcp.tcp__assembler import TcpAssembler
from pmd_net_proto.protocols.udp.udp__assembler import UdpAssembler
from pmd_net_proto._compat import as_buffer


class Ip6Assembler(Ip6[Ip6Payload], ProtoAssembler):
    """
    The IPv6 packet assembler.
    """

    _payload: Ip6Payload

    def __init__(
        self,
        *,
        ip6__src: Ip6Address = Ip6Address(),
        ip6__dst: Ip6Address = Ip6Address(),
        ip6__hop: int = IP6__DEFAULT_HOP_LIMIT,
        ip6__dscp: int = 0,
        ip6__ecn: int = 0,
        ip6__flow: int = 0,
        ip6__payload: Ip6Payload = RawAssembler(),
    ) -> None:
        """
        Initialize the IPv6 packet assembler.
        """

        self._tracker = ip6__payload.tracker

        self._payload = ip6__payload

        self._header = Ip6Header(
            dscp=ip6__dscp,
            ecn=ip6__ecn,
            flow=ip6__flow,
            dlen=len(self._payload),
            next=IpProto.from_proto(self._payload),
            hop=ip6__hop,
            src=ip6__src,
            dst=ip6__dst,
        )

    @override
    def assemble(self, buffers: list[Buffer], /) -> None:
        """
        Assemble the IPv6 packet into list of buffers.
        """

        buffers.append(as_buffer(bytearray(as_buffer(self._header))))

        if isinstance(
            self._payload,
            (TcpAssembler, UdpAssembler, Icmp6Assembler, RawAssembler),
        ):
            self._payload.pshdr_sum = self.pshdr_sum

        self._payload.assemble(buffers)
