################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the Raw protocol assembler.

pmd_net_proto/protocols/raw/raw__assembler.py

ver 3.0.7
"""

from __future__ import annotations

from typing_extensions import override

from pmd_net_proto.lib.buffer import Buffer
from pmd_net_proto.lib.enums import EtherType, IpProto
from pmd_net_proto.lib.proto_assembler import ProtoAssembler
from pmd_net_proto.lib.tracker import Tracker
from pmd_net_proto.protocols.raw.raw__base import Raw
from pmd_net_proto._compat import as_buffer


class RawAssembler(Raw, ProtoAssembler):
    """
    The Raw protocol assembler.
    """

    _payload: Buffer

    def __init__(
        self,
        *,
        raw__payload: Buffer = bytes(),
        ether_type: EtherType = EtherType.RAW,
        ip_proto: IpProto = IpProto.RAW,
        echo_tracker: Tracker | None = None,
    ) -> None:
        """
        Initialize the Raw protocol assembler.
        """

        self._tracker = Tracker(prefix="TX", echo_tracker=echo_tracker)

        self._payload = raw__payload
        self._ether_type = ether_type
        self._ip_proto = ip_proto

    @override
    def assemble(self, buffers: list[Buffer], /) -> None:
        """
        Assemble the Raw packet into list of buffers.
        """

        buffers.append(as_buffer(self._payload))
