################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the Tracker class used to generate serial-number
information for new packets.

pmd_net_proto/lib/tracker.py

ver 3.0.7
"""

from __future__ import annotations

import itertools
import time
from typing_extensions import override


class Tracker:
    """
    Class used to track packets.
    """

    _rx_counter = itertools.count()
    _tx_counter = itertools.count()

    def __init__(
        self,
        *,
        prefix: str,
        echo_tracker: Tracker | None = None,
        serial: str | None = None,
    ) -> None:
        """
        Initialize the Tracker.
        """

        self._echo_tracker: Tracker | None = echo_tracker
        self._timestamp: float
        self._serial: str

        if serial:
            self._serial = serial
            return

        assert prefix in {"RX", "TX"}, f"The 'prefix' argument must be 'RX' or 'TX'. Got: {prefix!r}"

        if prefix == "RX":
            self._timestamp = time.time()
            self._serial = f"<lg>RX{next(Tracker._rx_counter) & 0xFFFF:04X}</>"

        if prefix == "TX":
            self._timestamp = time.time()
            self._serial = f"<lr>TX{next(Tracker._tx_counter) & 0xFFFF:04X}</>"

    @override
    def __str__(self) -> str:
        """
        Get tracker as a string.
        """

        if self._echo_tracker:
            return f"{self._serial} {self._echo_tracker}"
        return self._serial

    @override
    def __repr__(self) -> str:
        """
        Get tracker as a string representation.
        """

        if self._echo_tracker is None:
            return f"Tracker(serial='{self._serial}')"

        return f"Tracker(serial='{self._serial}', echo_tracker={self._echo_tracker})"

    @property
    def echo_tracker(self) -> Tracker | None:
        """
        Get the '_echo_tracker' attribute.
        """

        return self._echo_tracker

    @property
    def timestamp(self) -> float:
        """
        Get the '_timestamp' attribute.
        """

        return self._timestamp

    @property
    def latency(self) -> str:
        """
        Get the latency between echo tracker timestamp and the current timestamp.
        """

        if self._echo_tracker:
            return f" {(time.time() - self._echo_tracker.timestamp) * 1000:.3f}ms"

        return ""
