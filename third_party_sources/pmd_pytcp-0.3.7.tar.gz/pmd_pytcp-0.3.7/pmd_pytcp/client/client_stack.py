################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the 'ClientStack' — the client-side mirror of the
'pmd_pytcp.stack' control surface.

'ClientStack' owns one IPC control connection to the daemon and exposes
a per-plane proxy ('.sysctl' / '.route' / '.link' / '.address' /
'.neighbor' / '.membership'). Each proxy mirrors the in-process API's
method signatures and marshals calls across the boundary — as
coroutines under the pure-asyncio runtime
('docs/refactor/pure_asyncio.md'). 'await connect(...)' is the entry
point; 'ClientStack' is also an async context manager.

pmd_pytcp/client/client_stack.py

ver 3.0.7
"""

from __future__ import annotations

import asyncio
from types import TracebackType
from typing_extensions import Self

from pmd_net_proto.lib.enums import EtherType, IpProto
from pmd_pytcp.client.client__address import ClientAddress
from pmd_pytcp.client.client__datagram_socket import ClientRawSocket, ClientUdpSocket
from pmd_pytcp.client.client__link import ClientLink
from pmd_pytcp.client.client__membership import ClientMembership
from pmd_pytcp.client.client__neighbor import ClientNeighbor
from pmd_pytcp.client.client__packet_socket import ClientPacketSocket
from pmd_pytcp.client.client__route import ClientRoute
from pmd_pytcp.client.client__sysctl import ClientSysctl
from pmd_pytcp.client.client__tcp_socket import ClientTcpSocket
from pmd_pytcp.ipc.ipc__client import IpcClient
from pmd_pytcp.ipc.ipc__errors import IpcConnectionError
from pmd_pytcp.socket import ETH_P_ALL, AddressFamily, SocketType

IPC__CLIENT__READINESS_POLL__SEC: float = 0.05


class ClientStack:
    """
    The client-side mirror of the 'pmd_pytcp.stack' control surface.
    """

    def __init__(self, *, socket_path: str) -> None:
        """
        Build the (not yet connected) IPC control connection and the
        per-plane proxies — 'await open()' (or the module-level
        'await connect(...)') establishes the connection.
        """

        self._client = IpcClient(socket_path=socket_path)
        self.sysctl = ClientSysctl(self._client)
        self.route = ClientRoute(self._client)
        self.link = ClientLink(self._client)
        self.address = ClientAddress(self._client)
        self.neighbor = ClientNeighbor(self._client)
        self.membership = ClientMembership(self._client)

    async def open(self) -> Self:
        """
        Open the IPC control connection to the daemon.
        """

        await self._client.open()
        return self

    async def socket(
        self,
        family: AddressFamily = AddressFamily.INET4,
        type: SocketType = SocketType.STREAM,
        protocol: IpProto | EtherType | int | None = None,
    ) -> ClientTcpSocket | ClientUdpSocket | ClientRawSocket | ClientPacketSocket:
        """
        Open a socket on the daemon, returning a client shim whose data
        path is a real selectable descriptor. Mirrors the in-process
        'socket()' factory's family / type / protocol arguments: STREAM
        yields a 'ClientTcpSocket', DGRAM a 'ClientUdpSocket', RAW on an
        INET family a 'ClientRawSocket' (with an IANA next-header
        'protocol'), and RAW on the PACKET family a 'ClientPacketSocket'
        (with an ethertype filter, default capture-all). A coroutine —
        opening is a daemon round trip.
        """

        if type == SocketType.STREAM:
            return await ClientTcpSocket.open(self._client, family=family)
        elif type == SocketType.DGRAM:
            return await ClientUdpSocket.open(self._client, family=family)
        elif type == SocketType.RAW:
            if family is AddressFamily.PACKET:
                if isinstance(protocol, IpProto):
                    raise ValueError("An AF_PACKET socket takes an ethertype, not an IpProto.")
                return await ClientPacketSocket.open(
                    self._client,
                    protocol=ETH_P_ALL if protocol is None else protocol,
                )
            if not isinstance(protocol, IpProto):
                raise ValueError("A raw IP socket requires an explicit IpProto next-header protocol.")
            return await ClientRawSocket.open(self._client, family=family, protocol=protocol)

        raise ValueError(f"Unsupported socket type {type!r}.")

    def close(self) -> None:
        """
        Close the control connection to the daemon.
        """

        self._client.close()

    async def __aenter__(self) -> Self:
        """
        Enter the client-stack context, returning the connected stack.
        """

        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """
        Close the control connection on context exit.
        """

        self.close()


async def connect(*, socket_path: str) -> ClientStack:
    """
    Connect to a PyTCP daemon and return a 'ClientStack' mirror.
    """

    return await ClientStack(socket_path=socket_path).open()


async def wait_for_daemon(*, socket_path: str, timeout: float = 5.0) -> None:
    """
    Wait until the daemon's control socket accepts a connection, so a
    client that races the daemon's startup can wait for readiness before
    'connect()'. Raises 'IpcConnectionError' if the daemon does not become
    ready within 'timeout' seconds.
    """

    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout
    while True:
        try:
            (await IpcClient(socket_path=socket_path).open()).close()
            return
        except OSError:
            if loop.time() >= deadline:
                raise IpcConnectionError(
                    f"PyTCP daemon did not become ready on {socket_path!r} within {timeout}s.",
                ) from None
            await asyncio.sleep(IPC__CLIENT__READINESS_POLL__SEC)
