################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the client-side mirror of the address control API.

'ClientAddress' marshals each address operation across the IPC control
channel to the daemon's 'pmd_pytcp.stack.address' API. The in-process 'add'
accepts an optional 'dad_conflict_callback' — an in-process callback that
cannot cross the boundary — so the mirror omits it; the daemon performs
the add with the callback defaulted to None.

pmd_pytcp/client/client__address.py

ver 3.0.7
"""

from __future__ import annotations

from typing import Union, cast

from pmd_net_addr import Ip4Address, Ip4IfAddr, Ip6Address, Ip6IfAddr
from pmd_pytcp.client.client__base import _DeviceScopedProxy
from pmd_pytcp.socket import AddressFamily
from typing_extensions import TypeAliasType

_AnyIfAddr = TypeAliasType("_AnyIfAddr", Union[Ip4IfAddr, Ip6IfAddr])


class ClientAddress(_DeviceScopedProxy):
    """
    The client-side mirror of the address control API.
    """

    _api_name = "address"

    async def add(self, *, ifaddr: _AnyIfAddr) -> None:
        """
        Assign an interface address to the bound interface.
        """

        await self._call("add", {"ifaddr": ifaddr})

    async def remove(self, *, address: Ip4Address | Ip6Address, abort_bound_sessions: bool = True) -> None:
        """
        Remove the interface address whose host part is 'address'.
        """

        await self._call("remove", {"address": address, "abort_bound_sessions": abort_bound_sessions})

    async def replace(
        self,
        *,
        old_address: Ip4Address | Ip6Address,
        new_ifaddr: _AnyIfAddr,
        abort_bound_sessions: bool = True,
    ) -> None:
        """
        Replace the interface address whose host part is 'old_address'.
        """

        await self._call(
            "replace",
            {
                "old_address": old_address,
                "new_ifaddr": new_ifaddr,
                "abort_bound_sessions": abort_bound_sessions,
            },
        )

    async def list_ifaddrs(self, *, family: AddressFamily | None = None) -> tuple[_AnyIfAddr, ...]:
        """
        List the bound interface's interface addresses.
        """

        return cast(tuple[_AnyIfAddr, ...], await self._call("list_ifaddrs", {"family": family}))
