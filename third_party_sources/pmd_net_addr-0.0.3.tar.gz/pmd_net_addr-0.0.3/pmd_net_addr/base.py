################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains the base class for all NetAddr objects.

pmd_net_addr/base.py

ver 3.0.7
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing_extensions import override


class Base(ABC):
    """
    NetAddr base class.
    """

    __slots__ = ()

    @override
    @abstractmethod
    def __str__(self) -> str:
        """
        Get the network object log string.
        """

        raise NotImplementedError

    @override
    def __repr__(self) -> str:
        """
        Get the network object representation string.
        """

        return f"{type(self).__name__}({str(self)!r})"

    @override
    @abstractmethod
    def __eq__(self, other: object, /) -> bool:
        """
        Check if two network objects are equal.
        """

        raise NotImplementedError

    @override
    @abstractmethod
    def __hash__(self) -> int:
        """
        Get the network object hash value. Concrete value types
        define this consistently with their own '__eq__' (every
        subclass overrides it).
        """

        raise NotImplementedError
