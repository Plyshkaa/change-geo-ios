################################################################################
##                                                                            ##
##   PyTCP - Python TCP/IP stack                                              ##
##   Copyright (C) 2020-present Sebastian Majewski                            ##
##                                                                            ##
##   This program is free software: you can redistribute it and/or modify     ##
##   it under the terms of the GNU General Public License as published by     ##
##   the Free Software Foundation, either version 3 of the License, or        ##
##   (at your option) any later version.                                      ##
##                                                                            ##
##   This program is distributed in the hope that it will be useful,          ##
##   but WITHOUT ANY WARRANTY; without even the implied warranty of           ##
##   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             ##
##   GNU General Public License for more details.                             ##
##                                                                            ##
##   You should have received a copy of the GNU General Public License        ##
##   along with this program. If not, see <https://www.gnu.org/licenses/>.    ##
##                                                                            ##
##   Author's email: ccie18643@gmail.com                                      ##
##   Github repository: https://github.com/ccie18643/PyTCP                    ##
##                                                                            ##
################################################################################


"""
This module contains Click type classes related to network addresses.

pmd_net_addr/click_types.py

ver 3.0.7
"""

from __future__ import annotations

from typing import NoReturn, TypeVar, Union
from typing_extensions import override

from click import ParamType
from click.core import Context, Parameter

# click's `ParamType` only became subscriptable in the 8.2 line (Python
# 3.10+). On the 8.1.x releases still installable on Python 3.9, the
# generic `ParamType[...]` bases below would fail at class-definition
# time, so add the PEP 560 hook when it is missing.
if not hasattr(ParamType, "__class_getitem__"):
    ParamType.__class_getitem__ = classmethod(  # type: ignore[attr-defined]
        lambda cls, item: cls
    )

from pmd_net_addr.errors import NetAddrError
from pmd_net_addr.ip4_address import Ip4Address
from pmd_net_addr.ip4_ifaddr import Ip4IfAddr
from pmd_net_addr.ip4_network import Ip4Network
from pmd_net_addr.ip6_address import Ip6Address
from pmd_net_addr.ip6_ifaddr import Ip6IfAddr
from pmd_net_addr.ip6_network import Ip6Network
from pmd_net_addr.mac_address import MacAddress


T = TypeVar("T")
def _fail( param_type: ParamType[T], /, *, message: str, param: Parameter | None, ctx: Context | None, ) -> NoReturn:
    """
    Raise the Click usage error for an invalid argument. Never
    returns: 'ParamType.fail' raises, and the trailing assert
    makes the no-return contract provable to every linter.
    """

    param_type.fail(message=message, param=param, ctx=ctx)
    raise AssertionError("unreachable: ParamType.fail() does not return")


class ClickTypeMacAddress(ParamType[MacAddress]):
    """
    Custom Click type for handling the MAC address argument.
    """

    name = "xx:xx:xx:xx:xx:xx"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> MacAddress:
        """
        Convert MAC address string to MacAddress object.
        """

        try:
            return MacAddress(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid MAC address argument '{value}'. Make sure to use format 'xx:xx:xx:xx:xx:xx'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIpAddress(ParamType[Union[Ip6Address, Ip4Address]]):
    """
    Custom Click type for handling IP address argument.
    """

    name = "x:x:x:x::x or x.x.x.x"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6Address | Ip4Address:
        """
        Convert IP address string to Ip6Address or Ip4Address object.
        """

        try:
            return Ip6Address(value)

        except NetAddrError:
            try:
                return Ip4Address(value)

            except NetAddrError:
                _fail(
                    self,
                    message=(
                        f"Invalid IP address argument '{value}'. Make sure to use "
                        f"format 'x:x:x:x::x' for IPv6 or 'x.x.x.x' for IPv4."
                    ),
                    param=param,
                    ctx=ctx,
                )


class ClickTypeIp6Address(ParamType[Ip6Address]):
    """
    Custom Click type for handling IPv6 address argument.
    """

    name = "x:x:x:x::x"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6Address:
        """
        Convert IPv6 address string to Ip6Address object.
        """

        try:
            return Ip6Address(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv6 address argument '{value}'. Make sure to use format 'x:x:x:x::x'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIp4Address(ParamType[Ip4Address]):
    """
    Custom Click type for handling IPv4 address argument.
    """

    name = "x.x.x.x"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip4Address:
        """
        Convert IPv4 address string to Ip4Address object.
        """

        try:
            return Ip4Address(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv4 address argument '{value}'. Make sure to use format 'x.x.x.x'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIpNetwork(ParamType[Union[Ip6Network, Ip4Network]]):
    """
    Custom Click type for handling IP network argument.
    """

    name = "x:x:x:x::x/n or x.x.x.x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6Network | Ip4Network:
        """
        Convert IP network string to Ip6Network or Ip4Network object.
        """

        try:
            return Ip6Network(value)

        except NetAddrError:
            try:
                return Ip4Network(value)

            except NetAddrError:
                _fail(
                    self,
                    message=(
                        f"Invalid IP network argument '{value}'. Make sure to use "
                        f"format 'x:x:x:x::x/n' for IPv6 or 'x.x.x.x/n' for IPv4."
                    ),
                    param=param,
                    ctx=ctx,
                )


class ClickTypeIp6Network(ParamType[Ip6Network]):
    """
    Custom Click type for handling IPv6 network argument.
    """

    name = "x:x:x:x::x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6Network:
        """
        Convert IPv6 network string to Ip6Network object.
        """

        try:
            return Ip6Network(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv6 network argument '{value}'. Make sure to use format 'x:x:x:x::x/n'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIp4Network(ParamType[Ip4Network]):
    """
    Custom Click type for handling IPv4 network argument.
    """

    name = "x.x.x.x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip4Network:
        """
        Convert IPv4 network string to Ip4Network object.
        """

        try:
            return Ip4Network(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv4 network argument '{value}'. Make sure to use format 'x.x.x.x/n'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIfAddr(ParamType[Union[Ip6IfAddr, Ip4IfAddr]]):
    """
    Custom Click type for handling IP host argument.
    """

    name = "x:x:x:x::x/n or x.x.x.x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6IfAddr | Ip4IfAddr:
        """
        Convert IP host string to Ip6IfAddr or Ip4IfAddr object.
        """

        try:
            return Ip6IfAddr(value)

        except NetAddrError:
            try:
                return Ip4IfAddr(value)

            except NetAddrError:
                _fail(
                    self,
                    message=(
                        f"Invalid IP host argument '{value}'. Make sure to use "
                        f"format 'x:x:x:x::x/n' for IPv6 or 'x.x.x.x/n' for IPv4."
                    ),
                    param=param,
                    ctx=ctx,
                )


class ClickTypeIp6IfAddr(ParamType[Ip6IfAddr]):
    """
    Custom Click type for handling IPv6 host argument.
    """

    name = "x:x:x:x::x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip6IfAddr:
        """
        Convert IPv6 host string to Ip6IfAddr object.
        """

        try:
            return Ip6IfAddr(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv6 host argument '{value}'. Make sure to use format 'x:x:x:x::x/n'.",
                param=param,
                ctx=ctx,
            )


class ClickTypeIp4IfAddr(ParamType[Ip4IfAddr]):
    """
    Custom Click type for handling IPv4 host argument.
    """

    name = "x.x.x.x/n"

    @override
    def convert(
        self,
        value: str,
        param: Parameter | None,
        ctx: Context | None,
    ) -> Ip4IfAddr:
        """
        Convert IPv4 host string to Ip4IfAddr object.
        """

        try:
            return Ip4IfAddr(value)

        except NetAddrError:
            _fail(
                self,
                message=f"Invalid IPv4 host argument '{value}'. Make sure to use format 'x.x.x.x/n'.",
                param=param,
                ctx=ctx,
            )
